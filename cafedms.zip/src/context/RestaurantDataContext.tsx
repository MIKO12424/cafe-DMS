import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  collection,
  doc,
  onSnapshot,
  setDoc,
  updateDoc,
  deleteDoc,
  writeBatch,
  query,
  orderBy,
  runTransaction
} from 'firebase/firestore';
import { db } from '../firebase/config';
import { handleFirestoreError, OperationType } from '../firebase/errorHandler';
import { useAuth } from './AuthContext';
import { 
  MenuItem, 
  RestaurantTable, 
  Order, 
  PaymentRecord, 
  OrderItem, 
  PaymentMethod 
} from '../types';

interface RestaurantDataContextType {
  menuItems: MenuItem[];
  tables: RestaurantTable[];
  orders: Order[];
  payments: PaymentRecord[];
  loading: boolean;
  addMenuItem: (item: Omit<MenuItem, 'id' | 'restaurantId' | 'createdAt'>) => Promise<string>;
  updateMenuItem: (id: string, updates: Partial<MenuItem>) => Promise<void>;
  toggleAvailability: (id: string, currentStatus: boolean) => Promise<void>;
  deleteMenuItem: (id: string) => Promise<void>;
  createOrder: (order: {
    orderType: 'dine-in' | 'takeaway';
    tableId?: string;
    tableName?: string;
    items: OrderItem[];
    totalAmount: number;
  }) => Promise<string>;
  addItemsToExistingOrder: (orderId: string, newItems: OrderItem[]) => Promise<void>;
  recordPayment: (params: {
    orderId: string;
    method: PaymentMethod;
    amount: number;
  }) => Promise<void>;
  updateTableConfig: (newCount: number) => Promise<void>;
  updateTableName: (tableId: string, newName: string) => Promise<void>;
}

const RestaurantDataContext = createContext<RestaurantDataContextType | undefined>(undefined);

export function RestaurantDataProvider({ children }: { children: React.ReactNode }) {
  const { restaurant, currentUser } = useAuth();
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [tables, setTables] = useState<RestaurantTable[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [loading, setLoading] = useState(true);

  const restaurantId = restaurant?.id;

  useEffect(() => {
    if (!restaurantId || !currentUser) {
      setMenuItems([]);
      setTables([]);
      setOrders([]);
      setPayments([]);
      setLoading(false);
      return;
    }

    setLoading(true);

    // 1. Menu Items Listener
    const menuCol = collection(db, 'restaurants', restaurantId, 'menu_items');
    const unsubMenu = onSnapshot(
      menuCol,
      (snapshot) => {
        const items: MenuItem[] = [];
        snapshot.forEach((docSnap) => {
          items.push({ id: docSnap.id, ...docSnap.data() } as MenuItem);
        });
        // Sort by category then name
        items.sort((a, b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name));
        setMenuItems(items);
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, `restaurants/${restaurantId}/menu_items`, currentUser);
      }
    );

    // 2. Tables Listener
    const tablesCol = collection(db, 'restaurants', restaurantId, 'tables');
    const unsubTables = onSnapshot(
      tablesCol,
      (snapshot) => {
        const tList: RestaurantTable[] = [];
        snapshot.forEach((docSnap) => {
          tList.push({ id: docSnap.id, ...docSnap.data() } as RestaurantTable);
        });
        tList.sort((a, b) => (a.number || 0) - (b.number || 0));
        setTables(tList);
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, `restaurants/${restaurantId}/tables`, currentUser);
      }
    );

    // 3. Orders Listener
    const ordersCol = collection(db, 'restaurants', restaurantId, 'orders');
    const ordersQuery = query(ordersCol, orderBy('createdAt', 'desc'));
    const unsubOrders = onSnapshot(
      ordersQuery,
      (snapshot) => {
        const oList: Order[] = [];
        snapshot.forEach((docSnap) => {
          oList.push({ id: docSnap.id, ...docSnap.data() } as Order);
        });
        setOrders(oList);
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, `restaurants/${restaurantId}/orders`, currentUser);
      }
    );

    // 4. Payments Listener
    const paymentsCol = collection(db, 'restaurants', restaurantId, 'payments');
    const paymentsQuery = query(paymentsCol, orderBy('createdAt', 'desc'));
    const unsubPayments = onSnapshot(
      paymentsQuery,
      (snapshot) => {
        const pList: PaymentRecord[] = [];
        snapshot.forEach((docSnap) => {
          pList.push({ id: docSnap.id, ...docSnap.data() } as PaymentRecord);
        });
        setPayments(pList);
        setLoading(false);
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, `restaurants/${restaurantId}/payments`, currentUser);
      }
    );

    return () => {
      unsubMenu();
      unsubTables();
      unsubOrders();
      unsubPayments();
    };
  }, [restaurantId, currentUser]);

  // Actions
  const addMenuItem = async (item: Omit<MenuItem, 'id' | 'restaurantId' | 'createdAt'>): Promise<string> => {
    if (!restaurantId || !currentUser) throw new Error('Unauthorized');
    const itemId = `item_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const newItem: MenuItem = {
      ...item,
      id: itemId,
      restaurantId,
      createdAt: new Date().toISOString(),
    };

    try {
      await setDoc(doc(db, 'restaurants', restaurantId, 'menu_items', itemId), newItem);
      return itemId;
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `restaurants/${restaurantId}/menu_items/${itemId}`, currentUser);
    }
  };

  const updateMenuItem = async (id: string, updates: Partial<MenuItem>) => {
    if (!restaurantId || !currentUser) throw new Error('Unauthorized');
    try {
      const ref = doc(db, 'restaurants', restaurantId, 'menu_items', id);
      await updateDoc(ref, {
        ...updates,
        updatedAt: new Date().toISOString(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `restaurants/${restaurantId}/menu_items/${id}`, currentUser);
    }
  };

  const toggleAvailability = async (id: string, currentStatus: boolean) => {
    await updateMenuItem(id, { isAvailable: !currentStatus });
  };

  const deleteMenuItem = async (id: string) => {
    if (!restaurantId || !currentUser) throw new Error('Unauthorized');
    try {
      await deleteDoc(doc(db, 'restaurants', restaurantId, 'menu_items', id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `restaurants/${restaurantId}/menu_items/${id}`, currentUser);
    }
  };

  const createOrder = async (orderData: {
    orderType: 'dine-in' | 'takeaway';
    tableId?: string;
    tableName?: string;
    items: OrderItem[];
    totalAmount: number;
  }): Promise<string> => {
    if (!restaurantId || !currentUser) throw new Error('Unauthorized');

    // Generate clean human-readable order number
    const count = orders.length + 1;
    const orderNumber = `#${(1000 + count).toString()}`;
    const orderId = `ord_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

    const newOrder: Order = {
      id: orderId,
      orderNumber,
      restaurantId,
      orderType: orderData.orderType,
      tableId: orderData.tableId || '',
      tableName: orderData.tableName || (orderData.orderType === 'takeaway' ? 'Takeaway' : ''),
      items: orderData.items,
      totalAmount: orderData.totalAmount,
      amountPaid: 0,
      remainingBalance: orderData.totalAmount,
      paymentStatus: 'unpaid',
      status: 'active',
      createdBy: currentUser.email || 'Staff',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    try {
      const batch = writeBatch(db);
      // 1. Create order
      const orderRef = doc(db, 'restaurants', restaurantId, 'orders', orderId);
      batch.set(orderRef, newOrder);

      // 2. If dine-in, mark table as occupied and link to order
      if (orderData.orderType === 'dine-in' && orderData.tableId) {
        const tableRef = doc(db, 'restaurants', restaurantId, 'tables', orderData.tableId);
        batch.update(tableRef, {
          status: 'occupied',
          activeOrderId: orderId,
          activeOrderNumber: orderNumber,
        });
      }

      await batch.commit();
      return orderId;
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `restaurants/${restaurantId}/orders/${orderId}`, currentUser);
    }
  };

  const addItemsToExistingOrder = async (orderId: string, newItems: OrderItem[]) => {
    if (!restaurantId || !currentUser) throw new Error('Unauthorized');
    const existingOrder = orders.find((o) => o.id === orderId);
    if (!existingOrder) throw new Error('Order not found');

    // Merge or append items while preserving historical snapshot prices
    const mergedItems = [...existingOrder.items];
    for (const newItem of newItems) {
      const existingItemIndex = mergedItems.findIndex((it) => it.itemId === newItem.itemId && it.price === newItem.price);
      if (existingItemIndex > -1) {
        mergedItems[existingItemIndex].quantity += newItem.quantity;
        mergedItems[existingItemIndex].subtotal += newItem.subtotal;
      } else {
        mergedItems.push(newItem);
      }
    }

    const newTotal = mergedItems.reduce((acc, curr) => acc + curr.subtotal, 0);
    const newRemaining = Math.max(0, newTotal - existingOrder.amountPaid);
    const newPaymentStatus = newRemaining === 0 ? 'paid' : (existingOrder.amountPaid > 0 ? 'partial' : 'unpaid');

    try {
      const orderRef = doc(db, 'restaurants', restaurantId, 'orders', orderId);
      await updateDoc(orderRef, {
        items: mergedItems,
        totalAmount: newTotal,
        remainingBalance: newRemaining,
        paymentStatus: newPaymentStatus,
        updatedAt: new Date().toISOString(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `restaurants/${restaurantId}/orders/${orderId}`, currentUser);
    }
  };

  const recordPayment = async (params: {
    orderId: string;
    method: PaymentMethod;
    amount: number;
  }) => {
    if (!restaurantId || !currentUser) throw new Error('Unauthorized');
    const targetOrder = orders.find((o) => o.id === params.orderId);
    if (!targetOrder) throw new Error('Order not found');

    if (params.amount <= 0) {
      throw new Error('Payment amount must be greater than zero.');
    }
    if (params.amount > targetOrder.remainingBalance) {
      throw new Error(`Payment cannot exceed the remaining balance of ETB ${targetOrder.remainingBalance.toFixed(2)}.`);
    }

    const paymentId = `pay_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const newAmountPaid = targetOrder.amountPaid + params.amount;
    const newRemainingBalance = Math.max(0, targetOrder.totalAmount - newAmountPaid);
    const isFullyPaid = newRemainingBalance === 0;
    const newPaymentStatus = isFullyPaid ? 'paid' : 'partial';
    const newOrderStatus = isFullyPaid ? 'completed' : 'active';

    const paymentDoc: PaymentRecord = {
      id: paymentId,
      restaurantId,
      orderId: targetOrder.id,
      orderNumber: targetOrder.orderNumber,
      tableName: targetOrder.tableName || 'Takeaway',
      method: params.method,
      amount: params.amount,
      staffMember: currentUser.email || 'Staff',
      createdAt: new Date().toISOString(),
    };

    try {
      const batch = writeBatch(db);

      // 1. Create immutable payment entry
      const payRef = doc(db, 'restaurants', restaurantId, 'payments', paymentId);
      batch.set(payRef, paymentDoc);

      // 2. Update order
      const orderRef = doc(db, 'restaurants', restaurantId, 'orders', targetOrder.id);
      batch.update(orderRef, {
        amountPaid: newAmountPaid,
        remainingBalance: newRemainingBalance,
        paymentStatus: newPaymentStatus,
        status: newOrderStatus,
        updatedAt: new Date().toISOString(),
      });

      // 3. If fully paid and dine-in, release table
      if (isFullyPaid && targetOrder.orderType === 'dine-in' && targetOrder.tableId) {
        const tableRef = doc(db, 'restaurants', restaurantId, 'tables', targetOrder.tableId);
        batch.update(tableRef, {
          status: 'available',
          activeOrderId: '',
          activeOrderNumber: '',
        });
      }

      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `restaurants/${restaurantId}/payments/${paymentId}`, currentUser);
    }
  };

  const updateTableConfig = async (newCount: number) => {
    if (!restaurantId || !currentUser) throw new Error('Unauthorized');
    if (newCount < 1 || newCount > 50) throw new Error('Table count must be between 1 and 50');

    try {
      const batch = writeBatch(db);
      // If expanding tables, create missing ones
      for (let i = 1; i <= newCount; i++) {
        const tableId = `table_${i}`;
        const existingTable = tables.find((t) => t.number === i || t.id === tableId);
        if (!existingTable) {
          const tRef = doc(db, 'restaurants', restaurantId, 'tables', tableId);
          batch.set(tRef, {
            id: tableId,
            restaurantId,
            name: `Table ${i}`,
            number: i,
            status: 'available',
          });
        }
      }
      // Update restaurant tableCount setting
      const restRef = doc(db, 'restaurants', restaurantId);
      batch.update(restRef, { tableCount: newCount });

      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `restaurants/${restaurantId}/tables`, currentUser);
    }
  };

  const updateTableName = async (tableId: string, newName: string) => {
    if (!restaurantId || !currentUser) throw new Error('Unauthorized');
    try {
      const ref = doc(db, 'restaurants', restaurantId, 'tables', tableId);
      await updateDoc(ref, { name: newName.trim() });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `restaurants/${restaurantId}/tables/${tableId}`, currentUser);
    }
  };

  return (
    <RestaurantDataContext.Provider
      value={{
        menuItems,
        tables,
        orders,
        payments,
        loading,
        addMenuItem,
        updateMenuItem,
        toggleAvailability,
        deleteMenuItem,
        createOrder,
        addItemsToExistingOrder,
        recordPayment,
        updateTableConfig,
        updateTableName,
      }}
    >
      {children}
    </RestaurantDataContext.Provider>
  );
}

export function useRestaurantData() {
  const context = useContext(RestaurantDataContext);
  if (!context) {
    throw new Error('useRestaurantData must be used within a RestaurantDataProvider');
  }
  return context;
}
