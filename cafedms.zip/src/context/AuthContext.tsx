import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  User as FirebaseUser, 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  sendPasswordResetEmail 
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  setDoc, 
  collection, 
  getDocs, 
  writeBatch,
  serverTimestamp 
} from 'firebase/firestore';
import { auth, db } from '../firebase/config';
import { handleFirestoreError, OperationType } from '../firebase/errorHandler';
import { UserProfile, Restaurant } from '../types';

interface AuthContextType {
  currentUser: FirebaseUser | null;
  userProfile: UserProfile | null;
  restaurant: Restaurant | null;
  loading: boolean;
  login: (email: string, pass: string) => Promise<void>;
  register: (restaurantName: string, managerName: string, email: string, pass: string) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchUserData = async (user: FirebaseUser) => {
    try {
      const userDocRef = doc(db, 'users', user.uid);
      let userDocSnap;
      try {
        userDocSnap = await getDoc(userDocRef);
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, `users/${user.uid}`, user);
      }

      if (userDocSnap.exists()) {
        const profile = userDocSnap.data() as UserProfile;
        setUserProfile(profile);

        // Fetch Restaurant details
        const restDocRef = doc(db, 'restaurants', profile.restaurantId);
        let restDocSnap;
        try {
          restDocSnap = await getDoc(restDocRef);
        } catch (err) {
          handleFirestoreError(err, OperationType.GET, `restaurants/${profile.restaurantId}`, user);
        }

        if (restDocSnap.exists()) {
          setRestaurant(restDocSnap.data() as Restaurant);
        }
      } else {
        // Fallback for user created before profile was stored
        const restaurantId = `rest_${user.uid.slice(0, 8)}`;
        const fallbackProfile: UserProfile = {
          uid: user.uid,
          email: user.email || '',
          restaurantId,
          restaurantName: 'CafeDMS Restaurant',
          role: 'owner',
          createdAt: new Date().toISOString(),
        };

        const fallbackRestaurant: Restaurant = {
          id: restaurantId,
          name: 'CafeDMS Restaurant',
          ownerId: user.uid,
          ownerEmail: user.email || '',
          currency: 'ETB',
          tableCount: 8,
          createdAt: new Date().toISOString(),
        };

        try {
          await setDoc(doc(db, 'restaurants', restaurantId), fallbackRestaurant);
          await setDoc(userDocRef, fallbackProfile);
          
          // Seed initial tables if none exist
          const tablesCol = collection(db, 'restaurants', restaurantId, 'tables');
          const tablesSnap = await getDocs(tablesCol);
          if (tablesSnap.empty) {
            const batch = writeBatch(db);
            for (let i = 1; i <= 8; i++) {
              const tableRef = doc(db, 'restaurants', restaurantId, 'tables', `table_${i}`);
              batch.set(tableRef, {
                id: `table_${i}`,
                restaurantId,
                name: `Table ${i}`,
                number: i,
                status: 'available',
              });
            }
            await batch.commit();
          }
        } catch (err) {
          handleFirestoreError(err, OperationType.WRITE, `restaurants/${restaurantId}`, user);
        }

        setUserProfile(fallbackProfile);
        setRestaurant(fallbackRestaurant);
      }
    } catch (err) {
      console.error('Error fetching user data:', err);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        await fetchUserData(user);
      } else {
        setUserProfile(null);
        setRestaurant(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const login = async (email: string, pass: string) => {
    const cred = await signInWithEmailAndPassword(auth, email.trim(), pass);
    await fetchUserData(cred.user);
  };

  const register = async (restaurantName: string, managerName: string, email: string, pass: string) => {
    const cred = await createUserWithEmailAndPassword(auth, email.trim(), pass);
    const user = cred.user;

    // Create unique restaurant ID for this business
    const restaurantId = `rest_${user.uid.slice(0, 8)}_${Date.now().toString(36)}`;

    const newRestaurant: Restaurant = {
      id: restaurantId,
      name: restaurantName.trim(),
      ownerId: user.uid,
      ownerEmail: user.email || email.trim(),
      managerName: managerName.trim() || 'Manager',
      currency: 'ETB',
      tableCount: 8,
      createdAt: new Date().toISOString(),
    };

    const newProfile: UserProfile = {
      uid: user.uid,
      email: user.email || email.trim(),
      managerName: managerName.trim() || 'Manager',
      restaurantId,
      restaurantName: restaurantName.trim(),
      role: 'manager',
      createdAt: new Date().toISOString(),
    };

    try {
      // 1. Create Restaurant document
      await setDoc(doc(db, 'restaurants', restaurantId), newRestaurant);

      // 2. Create User Profile document
      await setDoc(doc(db, 'users', user.uid), newProfile);

      // 3. Initialize default tables Table 1 to Table 8
      const batch = writeBatch(db);
      for (let i = 1; i <= 8; i++) {
        const tableRef = doc(db, 'restaurants', restaurantId, 'tables', `table_${i}`);
        batch.set(tableRef, {
          id: `table_${i}`,
          restaurantId,
          name: `Table ${i}`,
          number: i,
          status: 'available',
        });
      }
      await batch.commit();

      setUserProfile(newProfile);
      setRestaurant(newRestaurant);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `restaurants/${restaurantId}`, user);
    }
  };

  const resetPassword = async (email: string) => {
    await sendPasswordResetEmail(auth, email.trim());
  };

  const logout = async () => {
    await signOut(auth);
    setUserProfile(null);
    setRestaurant(null);
  };

  const refreshProfile = async () => {
    if (currentUser) {
      await fetchUserData(currentUser);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        restaurant,
        loading,
        login,
        register,
        resetPassword,
        logout,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
