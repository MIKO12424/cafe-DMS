import React from 'react';
import { Plus, ClipboardList, UtensilsCrossed } from 'lucide-react';
import { useRestaurantData } from '../context/RestaurantDataContext';

interface DashboardPageProps {
  onOpenNewOrder: () => void;
  onNavigateToTables: () => void;
  onNavigateToOrders: () => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  onOpenNewOrder,
  onNavigateToTables,
  onNavigateToOrders,
}) => {
  const { tables, orders, loading } = useRestaurantData();

  // Real Firestore counts
  const activeOrdersCount = orders.filter((o) => o.status === 'active').length;
  const availableTablesCount = tables.filter((t) => t.status === 'available').length;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      {/* Page Title */}
      <div className="mb-8 text-center sm:text-left">
        <h1 className="text-2xl sm:text-3xl font-bold font-serif text-[#3A2010]">
          Dashboard
        </h1>
        <p className="text-sm text-[#7D6352] mt-1">
          Real-time restaurant operational overview
        </p>
      </div>

      {/* Primary Action: One Large, Prominent "+ Add New Order" Button */}
      <div className="mb-10">
        <button
          onClick={onOpenNewOrder}
          className="w-full group relative overflow-hidden py-6 sm:py-8 px-6 bg-linear-to-r from-[#4A2E18] to-[#613A1E] hover:from-[#3B2412] hover:to-[#502F17] text-[#FFFDF9] rounded-2xl shadow-xl shadow-[#4A2E18]/15 border border-[#6B4226]/50 transition-all transform active:scale-[0.99] flex flex-col sm:flex-row items-center justify-center gap-4 text-center cursor-pointer"
        >
          <div className="w-14 h-14 rounded-full bg-[#FFFDF9]/10 border border-[#FFFDF9]/20 flex items-center justify-center text-[#F2DFCD] group-hover:scale-110 transition-transform">
            <Plus className="w-8 h-8 stroke-[2.5]" />
          </div>
          <div>
            <span className="block text-2xl sm:text-3xl font-bold tracking-tight">
              + Add New Order
            </span>
            <span className="block text-xs sm:text-sm text-[#F0DFCF] font-medium mt-1">
              Create a Dine In or Takeaway order with live menu items
            </span>
          </div>
        </button>
      </div>

      {/* The ONLY Two Widgets Allowed: Active Orders count & Available Tables count */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        {/* Widget 1: Active Orders count */}
        <div 
          onClick={onNavigateToOrders}
          className="bg-[#FFFDF9] border border-[#EADBCE] rounded-2xl p-6 sm:p-8 shadow-sm hover:shadow-md transition-shadow cursor-pointer flex items-center justify-between group"
        >
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-[#8C6D53]">
              Active Orders
            </span>
            <div className="text-4xl sm:text-5xl font-extrabold text-[#3A2010] mt-2 font-serif">
              {loading ? (
                <span className="inline-block w-8 h-8 border-4 border-[#8C6D53]/20 border-t-[#8C6D53] rounded-full animate-spin" />
              ) : (
                activeOrdersCount
              )}
            </div>
            <p className="text-xs text-[#9E826C] mt-2">
              Orders currently open or awaiting full payment
            </p>
          </div>
          <div className="w-14 h-14 rounded-2xl bg-[#F7EFE6] text-[#6B4226] flex items-center justify-center group-hover:scale-105 transition-transform">
            <ClipboardList className="w-7 h-7" />
          </div>
        </div>

        {/* Widget 2: Available Tables count */}
        <div 
          onClick={onNavigateToTables}
          className="bg-[#FFFDF9] border border-[#EADBCE] rounded-2xl p-6 sm:p-8 shadow-sm hover:shadow-md transition-shadow cursor-pointer flex items-center justify-between group"
        >
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-[#8C6D53]">
              Available Tables
            </span>
            <div className="text-4xl sm:text-5xl font-extrabold text-[#3A2010] mt-2 font-serif">
              {loading ? (
                <span className="inline-block w-8 h-8 border-4 border-[#8C6D53]/20 border-t-[#8C6D53] rounded-full animate-spin" />
              ) : (
                availableTablesCount
              )}
            </div>
            <p className="text-xs text-[#9E826C] mt-2">
              Ready to seat new dine-in guests
            </p>
          </div>
          <div className="w-14 h-14 rounded-2xl bg-[#EAF2EB] text-[#2F683A] flex items-center justify-center group-hover:scale-105 transition-transform">
            <UtensilsCrossed className="w-7 h-7" />
          </div>
        </div>
      </div>
    </div>
  );
};
