import React, { useState, useMemo } from 'react';
import { 
  Receipt, 
  Banknote, 
  Smartphone, 
  CreditCard, 
  Search, 
  Lock, 
  Unlock, 
  KeyRound, 
  AlertCircle, 
  Delete,
  ShieldCheck
} from 'lucide-react';
import { useRestaurantData } from '../context/RestaurantDataContext';
import { PaymentRecord, PaymentMethod, Order } from '../types';

interface PaymentsPageProps {
  onOpenPaymentForOrder: (order: Order) => void;
}

export const PaymentsPage: React.FC<PaymentsPageProps> = ({
  onOpenPaymentForOrder,
}) => {
  const { payments, orders, loading } = useRestaurantData();

  // Security PIN Lock State (Locked by default, PIN: 506790)
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [enteredPin, setEnteredPin] = useState('');
  const [pinError, setPinError] = useState<string | null>(null);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [filterMethod, setFilterMethod] = useState<'all' | PaymentMethod>('all');

  // Quick Settle selector
  const unpaidOrders = useMemo(() => {
    return orders.filter((o) => o.status === 'active' && o.remainingBalance > 0);
  }, [orders]);

  // Check if a payment happened "today" in the user's local timezone
  const isToday = (isoString: string) => {
    try {
      const paymentDate = new Date(isoString);
      const today = new Date();
      return (
        paymentDate.getFullYear() === today.getFullYear() &&
        paymentDate.getMonth() === today.getMonth() &&
        paymentDate.getDate() === today.getDate()
      );
    } catch {
      return false;
    }
  };

  // Today's Payment Totals
  const todayPayments = useMemo(() => {
    return payments.filter((p) => isToday(p.createdAt));
  }, [payments]);

  const totalCollectedToday = useMemo(() => {
    return todayPayments.reduce((sum, p) => sum + (p.amount || 0), 0);
  }, [todayPayments]);

  const cashToday = useMemo(() => {
    return todayPayments
      .filter((p) => p.method === 'Cash')
      .reduce((sum, p) => sum + (p.amount || 0), 0);
  }, [todayPayments]);

  const telebirrToday = useMemo(() => {
    return todayPayments
      .filter((p) => p.method === 'Telebirr')
      .reduce((sum, p) => sum + (p.amount || 0), 0);
  }, [todayPayments]);

  const cbeToday = useMemo(() => {
    return todayPayments
      .filter((p) => p.method === 'CBE')
      .reduce((sum, p) => sum + (p.amount || 0), 0);
  }, [todayPayments]);

  // Filtered Payment History
  const filteredPayments = useMemo(() => {
    return payments.filter((p) => {
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        !q ||
        p.orderNumber.toLowerCase().includes(q) ||
        (p.tableName && p.tableName.toLowerCase().includes(q)) ||
        (p.staffMember && p.staffMember.toLowerCase().includes(q));

      const matchMethod = filterMethod === 'all' || p.method === filterMethod;

      return matchSearch && matchMethod;
    });
  }, [payments, searchQuery, filterMethod]);

  const formatDateTime = (isoString: string) => {
    try {
      const d = new Date(isoString);
      return d.toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return isoString;
    }
  };

  const handleDigitPress = (digit: string) => {
    if (enteredPin.length < 6) {
      const nextPin = enteredPin + digit;
      setEnteredPin(nextPin);
      setPinError(null);

      if (nextPin.length === 6) {
        if (nextPin === '506790') {
          setIsUnlocked(true);
          setEnteredPin('');
          setPinError(null);
        } else {
          setPinError('Incorrect PIN. Please try again.');
          setEnteredPin('');
        }
      }
    }
  };

  const handleBackspace = () => {
    setEnteredPin((prev) => prev.slice(0, -1));
    setPinError(null);
  };

  // IF LOCKED: Show Security PIN Screen
  if (!isUnlocked) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 flex flex-col items-center">
        <div className="bg-[#FFFDF9] border border-[#EADBCE] rounded-3xl p-8 shadow-xl w-full text-center">
          
          <div className="w-16 h-16 rounded-2xl bg-[#4A2E18] text-[#FDFBF7] flex items-center justify-center mx-auto mb-4 shadow-lg shadow-[#4A2E18]/15">
            <Lock className="w-8 h-8" />
          </div>

          <h2 className="text-xl font-bold font-serif text-[#3A2010]">
            Payments Locked
          </h2>
          <p className="text-xs text-[#7D6352] mt-1 mb-6">
            Enter the 6-digit authorization PIN to unlock payments, daily collections, and settlements.
          </p>

          {/* Masked PIN Indicators */}
          <div className="flex justify-center items-center gap-2.5 mb-6">
            {[0, 1, 2, 3, 4, 5].map((idx) => {
              const filled = idx < enteredPin.length;
              return (
                <div
                  key={idx}
                  className={`w-9 h-11 rounded-xl flex items-center justify-center text-xl font-bold font-mono transition-all ${
                    pinError
                      ? 'border-2 border-[#C45E47] bg-[#FDF0ED] text-[#A63A24]'
                      : filled
                      ? 'border-2 border-[#4A2E18] bg-[#F5ECE1] text-[#3A2010]'
                      : 'border border-[#D9C8B5] bg-[#FDFBF7] text-[#B5A08E]'
                  }`}
                >
                  {filled ? '•' : ''}
                </div>
              );
            })}
          </div>

          {/* Error Message */}
          {pinError && (
            <div className="mb-4 p-2.5 bg-[#FDF0ED] border border-[#F5C6BA] rounded-xl text-xs text-[#A63A24] flex items-center justify-center gap-2 font-medium">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              <span>{pinError}</span>
            </div>
          )}

          {/* Keypad */}
          <div className="grid grid-cols-3 gap-2.5 mb-3">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => handleDigitPress(d)}
                className="py-3 bg-[#FAF5EF] hover:bg-[#F2E8DC] active:bg-[#4A2E18] active:text-white border border-[#E8DCCF] rounded-2xl text-lg font-bold text-[#3A2010] transition-colors shadow-2xs cursor-pointer select-none"
              >
                {d}
              </button>
            ))}
            <button
              type="button"
              onClick={() => setEnteredPin('')}
              className="py-3 bg-[#FAF5EF] hover:bg-[#F2E8DC] text-[#7D6352] text-xs font-bold rounded-2xl transition-colors cursor-pointer"
            >
              Clear
            </button>
            <button
              type="button"
              onClick={() => handleDigitPress('0')}
              className="py-3 bg-[#FAF5EF] hover:bg-[#F2E8DC] active:bg-[#4A2E18] active:text-white border border-[#E8DCCF] rounded-2xl text-lg font-bold text-[#3A2010] transition-colors shadow-2xs cursor-pointer select-none"
            >
              0
            </button>
            <button
              type="button"
              onClick={handleBackspace}
              className="py-3 bg-[#FAF5EF] hover:bg-[#F2E8DC] text-[#7D6352] hover:text-[#A63A24] flex items-center justify-center rounded-2xl transition-colors cursor-pointer"
              title="Backspace"
            >
              <Delete className="w-5 h-5" />
            </button>
          </div>

          <div className="pt-3 border-t border-[#EADBCE] text-[11px] text-[#8C6D53] flex items-center justify-center gap-1.5">
            <KeyRound className="w-3.5 h-3.5 text-[#8C5835]" />
            <span>Authorized Manager Access</span>
          </div>

        </div>
      </div>
    );
  }

  // IF UNLOCKED: Full Payments Dashboard & Ledger
  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-bold font-serif text-[#3A2010]">
              Payments & Collections
            </h1>
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-[#EDF7EE] text-[#28662F] border border-[#C6E6C8]">
              <ShieldCheck className="w-3 h-3" />
              PIN Authorized
            </span>
          </div>
          <p className="text-sm text-[#7D6352] mt-1">
            Real-time revenue settlement, daily payment breakdowns, and audit ledger
          </p>
        </div>

        {/* Header Actions */}
        <div className="flex items-center gap-3">
          {/* Quick Settle Outstanding Order Action */}
          {unpaidOrders.length > 0 && (
            <div className="flex items-center gap-2">
              <select
                onChange={(e) => {
                  const o = unpaidOrders.find((ord) => ord.id === e.target.value);
                  if (o) onOpenPaymentForOrder(o);
                  e.target.value = '';
                }}
                defaultValue=""
                className="px-3 py-2 bg-[#4A2E18] text-[#FFFDF9] text-xs font-bold rounded-xl shadow-xs cursor-pointer focus:outline-none"
              >
                <option value="" disabled>
                  Settle Open Order ({unpaidOrders.length})
                </option>
                {unpaidOrders.map((ord) => (
                  <option key={ord.id} value={ord.id}>
                    {ord.orderNumber} ({ord.tableName || 'Takeaway'}) - Bal: ETB {ord.remainingBalance.toFixed(2)}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Re-Lock Payments Option Button */}
          <button
            onClick={() => setIsUnlocked(false)}
            className="flex items-center gap-1.5 px-3 py-2 bg-[#F2E8DC] hover:bg-[#EADBCE] text-[#4A2E18] text-xs font-bold rounded-xl border border-[#D9C8B5] transition-colors cursor-pointer"
            title="Lock payment access with PIN 506790"
          >
            <Lock className="w-3.5 h-3.5 text-[#8C5835]" />
            <span>Lock</span>
          </button>
        </div>
      </div>

      {/* TODAY'S SUMMARY CARDS (EXCLUSIVELY HERE, NOT ON DASHBOARD) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {/* Total Collected Today */}
        <div className="bg-[#FFFDF9] border border-[#DEB992] rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#8C6D53]">
              Collected Today
            </span>
            <div className="w-8 h-8 rounded-lg bg-[#FAF2E8] text-[#4A2E18] flex items-center justify-center">
              <Receipt className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-[#3A2010] font-mono">
            ETB {totalCollectedToday.toFixed(2)}
          </div>
          <span className="text-[11px] text-[#A68872] mt-1 block">
            {todayPayments.length} transactions today
          </span>
        </div>

        {/* Cash Collected Today */}
        <div className="bg-[#FFFDF9] border border-[#EADBCE] rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#6B4226]">
              Cash Today
            </span>
            <div className="w-8 h-8 rounded-lg bg-[#EDF7EE] text-[#28662F] flex items-center justify-center">
              <Banknote className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-[#28662F] font-mono">
            ETB {cashToday.toFixed(2)}
          </div>
          <span className="text-[11px] text-[#8C6D53] mt-1 block">
            Physical cash drawer
          </span>
        </div>

        {/* Telebirr Collected Today */}
        <div className="bg-[#FFFDF9] border border-[#EADBCE] rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#6B4226]">
              Telebirr Today
            </span>
            <div className="w-8 h-8 rounded-lg bg-[#EBF2F7] text-[#1E5685] flex items-center justify-center">
              <Smartphone className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-[#1E5685] font-mono">
            ETB {telebirrToday.toFixed(2)}
          </div>
          <span className="text-[11px] text-[#8C6D53] mt-1 block">
            Telebirr mobile transfer
          </span>
        </div>

        {/* CBE Collected Today */}
        <div className="bg-[#FFFDF9] border border-[#EADBCE] rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#6B4226]">
              CBE Today
            </span>
            <div className="w-8 h-8 rounded-lg bg-[#F8EEF2] text-[#8C2356] flex items-center justify-center">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-[#8C2356] font-mono">
            ETB {cbeToday.toFixed(2)}
          </div>
          <span className="text-[11px] text-[#8C6D53] mt-1 block">
            Commercial Bank of Ethiopia
          </span>
        </div>
      </div>

      {/* Search & Filter Header for History */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <h2 className="text-lg font-bold font-serif text-[#3A2010]">
          Payment Transaction History
        </h2>

        <div className="flex flex-wrap items-center gap-2">
          {/* Search */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[#A89078]" />
            <input
              type="text"
              placeholder="Search order #, table, staff..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8 pr-3 py-1.5 text-xs bg-[#FFFDF9] border border-[#D9C8B5] rounded-xl text-[#3A2010] placeholder-[#B5A08E] focus:outline-none"
            />
          </div>

          {/* Filter by Method */}
          <select
            value={filterMethod}
            onChange={(e) => setFilterMethod(e.target.value as any)}
            className="px-3 py-1.5 bg-[#FFFDF9] border border-[#D9C8B5] rounded-xl text-xs text-[#6B4226] font-medium focus:outline-none"
          >
            <option value="all">All Methods</option>
            <option value="Cash">Cash</option>
            <option value="Telebirr">Telebirr</option>
            <option value="CBE">CBE</option>
          </select>
        </div>
      </div>

      {/* Payment History Table */}
      <div className="bg-[#FFFDF9] border border-[#EADBCE] rounded-2xl overflow-hidden shadow-xs">
        {loading ? (
          <div className="text-center py-16">
            <div className="inline-block w-8 h-8 border-4 border-[#8C6D53]/20 border-t-[#8C6D53] rounded-full animate-spin mb-3" />
            <p className="text-xs text-[#8C6D53]">Loading payment history...</p>
          </div>
        ) : filteredPayments.length === 0 ? (
          <div className="text-center py-16 px-4">
            <Receipt className="w-12 h-12 text-[#CBB29C] mx-auto mb-3" />
            <h3 className="text-base font-bold text-[#3A2010]">
              No payment transactions yet
            </h3>
            <p className="text-xs text-[#8C6D53] mt-1 max-w-sm mx-auto">
              Payments recorded via Cash, Telebirr, or CBE will appear in this immutable financial ledger.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-[#FAF5EF] border-b border-[#EADBCE] text-[#6B4226] uppercase font-bold text-[10px] tracking-wider">
                  <th className="py-3.5 px-4">Date & Time</th>
                  <th className="py-3.5 px-4">Order #</th>
                  <th className="py-3.5 px-4">Table / Destination</th>
                  <th className="py-3.5 px-4">Payment Method</th>
                  <th className="py-3.5 px-4">Staff Member</th>
                  <th className="py-3.5 px-4 text-right">Amount (ETB)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EADBCE]/60">
                {filteredPayments.map((p) => {
                  let badgeClass = 'bg-[#F2E8DC] text-[#6B4226]';
                  if (p.method === 'Telebirr') badgeClass = 'bg-[#EBF2F7] text-[#1E5685] border border-[#C5DCF0]';
                  if (p.method === 'Cash') badgeClass = 'bg-[#EDF7EE] text-[#28662F] border border-[#C6E6C8]';
                  if (p.method === 'CBE') badgeClass = 'bg-[#F8EEF2] text-[#8C2356] border border-[#ECCBD9]';

                  return (
                    <tr key={p.id} className="hover:bg-[#FDFBF7] transition-colors">
                      <td className="py-3.5 px-4 text-[#7D6352]">
                        {formatDateTime(p.createdAt)}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-[#3A2010]">
                        {p.orderNumber}
                      </td>
                      <td className="py-3.5 px-4 text-[#593E2B]">
                        {p.tableName || 'Takeaway'}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-bold ${badgeClass}`}>
                          {p.method}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-[#7D6352] truncate max-w-[150px]">
                        {p.staffMember}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono font-bold text-sm text-[#3A2010]">
                        ETB {p.amount.toFixed(2)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
