import React, { useState } from 'react';
import { 
  UtensilsCrossed, 
  CheckCircle, 
  AlertCircle, 
  Plus, 
  Edit2, 
  Receipt, 
  Sliders, 
  X,
  Check
} from 'lucide-react';
import { useRestaurantData } from '../context/RestaurantDataContext';
import { RestaurantTable, Order } from '../types';

interface TablesPageProps {
  onStartDineInOrder: (tableId: string, tableName: string) => void;
  onOpenOrderDetails: (order: Order) => void;
  onOpenAddItems: (order: Order) => void;
  onOpenPayment: (order: Order) => void;
}

export const TablesPage: React.FC<TablesPageProps> = ({
  onStartDineInOrder,
  onOpenOrderDetails,
  onOpenAddItems,
  onOpenPayment,
}) => {
  const { tables, orders, updateTableConfig, updateTableName, loading } = useRestaurantData();

  const [isConfiguring, setIsConfiguring] = useState(false);
  const [newCount, setNewCount] = useState(tables.length || 8);
  const [editingTableId, setEditingTableId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  const availableCount = tables.filter((t) => t.status === 'available').length;
  const occupiedCount = tables.filter((t) => t.status === 'occupied').length;

  const handleSaveConfig = async () => {
    try {
      await updateTableConfig(newCount);
      setIsConfiguring(false);
      setFeedbackMsg(`Updated table setup to ${newCount} tables.`);
      setTimeout(() => setFeedbackMsg(null), 3000);
    } catch (err: any) {
      alert(err.message || 'Failed to update table configuration');
    }
  };

  const handleSaveName = async (tableId: string) => {
    if (!editingName.trim()) return;
    try {
      await updateTableName(tableId, editingName.trim());
      setEditingTableId(null);
      setEditingName('');
    } catch (err: any) {
      alert(err.message || 'Failed to rename table');
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-serif text-[#3A2010]">
            Restaurant Tables
          </h1>
          <p className="text-sm text-[#7D6352] mt-1">
            Real-time occupancy status and table management
          </p>
        </div>

        {/* Stats & Actions */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-[#FFFDF9] border border-[#EADBCE] px-3.5 py-1.5 rounded-xl text-xs font-medium text-[#6B4226]">
            <span className="flex items-center gap-1 text-[#28662F]">
              <span className="w-2 h-2 rounded-full bg-[#34A853]" />
              {availableCount} Available
            </span>
            <span className="text-[#CBB29C]">•</span>
            <span className="flex items-center gap-1 text-[#B06014]">
              <span className="w-2 h-2 rounded-full bg-[#E37400]" />
              {occupiedCount} Occupied
            </span>
          </div>

          <button
            onClick={() => {
              setNewCount(tables.length || 8);
              setIsConfiguring(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#F2E8DC] hover:bg-[#EADBCE] text-[#4A2E18] text-xs font-semibold rounded-xl border border-[#D9C8B5] transition-colors"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Configure</span>
          </button>
        </div>
      </div>

      {feedbackMsg && (
        <div className="mb-6 p-3 bg-[#EDF7EE] border border-[#C6E6C8] rounded-xl text-xs text-[#28662F] flex items-center gap-2">
          <CheckCircle className="w-4 h-4" />
          <span>{feedbackMsg}</span>
        </div>
      )}

      {/* Configure Modal */}
      {isConfiguring && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#FFFDF9] border border-[#EADBCE] rounded-2xl max-w-sm w-full p-6 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-[#3A2010]">
                Configure Total Tables
              </h3>
              <button
                onClick={() => setIsConfiguring(false)}
                className="text-[#9E826C] hover:text-[#3A2010]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-[#7D6352] mb-4">
              Specify how many dining tables are in your restaurant (1 to 50):
            </p>
            <div className="mb-5">
              <input
                type="number"
                min={1}
                max={50}
                value={newCount}
                onChange={(e) => setNewCount(parseInt(e.target.value) || 1)}
                className="w-full px-4 py-2.5 bg-[#FDFBF7] border border-[#D9C8B5] rounded-xl text-sm font-semibold text-[#2D1B0E] focus:outline-none focus:ring-2 focus:ring-[#8C5835]"
              />
            </div>
            <div className="flex justify-end gap-2.5">
              <button
                onClick={() => setIsConfiguring(false)}
                className="px-4 py-2 text-xs font-medium text-[#7D6352] hover:bg-[#F2E8DC] rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveConfig}
                className="px-4 py-2 text-xs font-semibold bg-[#4A2E18] text-[#FFFDF9] hover:bg-[#38200F] rounded-xl shadow-sm"
              >
                Save Tables
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Loading state */}
      {loading && (
        <div className="text-center py-16">
          <div className="inline-block w-8 h-8 border-4 border-[#8C6D53]/20 border-t-[#8C6D53] rounded-full animate-spin mb-3" />
          <p className="text-xs text-[#8C6D53]">Loading tables...</p>
        </div>
      )}

      {/* Tables Grid - Compact & Attractive Cards */}
      {!loading && (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {tables.map((table) => {
            const isOccupied = table.status === 'occupied';
            // Find active order linked to this table
            const linkedOrder = orders.find(
              (o) => o.status === 'active' && (o.id === table.activeOrderId || o.tableId === table.id)
            );

            return (
              <div
                key={table.id}
                className={`relative bg-[#FFFDF9] rounded-2xl border transition-all overflow-hidden flex flex-col justify-between p-4.5 ${
                  isOccupied
                    ? 'border-[#DEB992] shadow-sm bg-linear-to-b from-[#FFFDF9] to-[#FDF8F0]'
                    : 'border-[#EADBCE] hover:border-[#C4A992] shadow-xs hover:shadow-sm'
                }`}
              >
                {/* Top Status & Name */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    {/* Status Badge */}
                    <span
                      className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider ${
                        isOccupied
                          ? 'bg-[#F9ECE0] text-[#A65111] border border-[#EDB993]'
                          : 'bg-[#EDF7EE] text-[#28662F] border border-[#C6E6C8]'
                      }`}
                    >
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          isOccupied ? 'bg-[#E37400]' : 'bg-[#34A853]'
                        }`}
                      />
                      {isOccupied ? 'Occupied' : 'Available'}
                    </span>

                    {/* Quick rename button */}
                    {editingTableId !== table.id ? (
                      <button
                        onClick={() => {
                          setEditingTableId(table.id);
                          setEditingName(table.name);
                        }}
                        className="text-[#B59C86] hover:text-[#4A2E18] p-1 rounded transition-colors"
                        title="Rename Table"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                    ) : null}
                  </div>

                  {/* Table Display Name */}
                  {editingTableId === table.id ? (
                    <div className="flex items-center gap-1.5 my-2">
                      <input
                        type="text"
                        value={editingName}
                        onChange={(e) => setEditingName(e.target.value)}
                        className="flex-1 px-2.5 py-1 text-sm bg-white border border-[#8C5835] rounded-lg font-bold text-[#3A2010]"
                        autoFocus
                      />
                      <button
                        onClick={() => handleSaveName(table.id)}
                        className="p-1.5 bg-[#4A2E18] text-white rounded-lg hover:bg-[#38200F]"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setEditingTableId(null)}
                        className="p-1.5 bg-[#EADBCE] text-[#4A2E18] rounded-lg"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-8 h-8 rounded-xl bg-[#F7EFE6] text-[#6B4226] flex items-center justify-center font-bold text-sm">
                        {table.number}
                      </div>
                      <h3 className="text-base font-bold text-[#3A2010]">
                        {table.name}
                      </h3>
                    </div>
                  )}

                  {/* Occupied Order Info */}
                  {isOccupied && linkedOrder && (
                    <div className="bg-[#FAF2E8] border border-[#E8D4BF] rounded-xl p-2.5 my-2 text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-[#6B4226]">
                          {linkedOrder.orderNumber}
                        </span>
                        <span className="font-mono font-bold text-[#3A2010]">
                          ETB {linkedOrder.totalAmount.toFixed(2)}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[11px] text-[#8C6D53]">
                        <span>{linkedOrder.items.length} items</span>
                        <span>
                          Bal: ETB {linkedOrder.remainingBalance.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Card Actions */}
                <div className="mt-3 pt-3 border-t border-[#EADBCE]/60">
                  {isOccupied && linkedOrder ? (
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => onOpenAddItems(linkedOrder)}
                        className="w-full flex items-center justify-center gap-1 py-1.5 px-2 bg-[#F2E8DC] hover:bg-[#E8D8C7] text-[#4A2E18] text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                        title="Add items to existing active order"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>+ Items</span>
                      </button>
                      <button
                        onClick={() => onOpenPayment(linkedOrder)}
                        className="w-full flex items-center justify-center gap-1 py-1.5 px-2 bg-[#4A2E18] hover:bg-[#38200F] text-[#FFFDF9] text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                        title="Record payment and settle"
                      >
                        <Receipt className="w-3.5 h-3.5" />
                        <span>Settle</span>
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => onStartDineInOrder(table.id, table.name)}
                      className="w-full flex items-center justify-center gap-1.5 py-2 px-3 bg-[#FFFDF9] hover:bg-[#4A2E18] text-[#4A2E18] hover:text-[#FFFDF9] border border-[#4A2E18]/30 hover:border-[#4A2E18] text-xs font-bold rounded-xl transition-all cursor-pointer shadow-2xs"
                    >
                      <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                      <span>Seat & Order</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
