import React, { useState, useMemo } from 'react';
import { 
  Plus, 
  Edit3, 
  Trash2, 
  Search, 
  Check, 
  X, 
  AlertCircle, 
  CheckCircle2, 
  Image as ImageIcon,
  ToggleLeft,
  ToggleRight,
  BookOpen
} from 'lucide-react';
import { useRestaurantData } from '../context/RestaurantDataContext';
import { ImagePreview } from '../components/ImagePreview';
import { MenuItem } from '../types';

export const MenuManagementPage: React.FC = () => {
  const { menuItems, addMenuItem, updateMenuItem, toggleAvailability, deleteMenuItem, loading } = useRestaurantData();

  // Search & Category Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  // Modal State for Add / Edit
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);

  // Form Fields
  const [itemName, setItemName] = useState('');
  const [itemCategory, setItemCategory] = useState('');
  const [itemPrice, setItemPrice] = useState('');
  const [itemImageUrl, setItemImageUrl] = useState('');

  // Delete Confirmation
  const [deletingItem, setDeletingItem] = useState<MenuItem | null>(null);

  // Feedback Messages
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Preset Common Categories
  const commonCategories = ['Coffee', 'Tea', 'Pastry', 'Breakfast', 'Lunch', 'Cold Drinks', 'Dessert'];

  const categories = useMemo(() => {
    const set = new Set<string>();
    menuItems.forEach((m) => {
      if (m.category) set.add(m.category);
    });
    return ['All', ...Array.from(set)];
  }, [menuItems]);

  const filteredItems = useMemo(() => {
    return menuItems.filter((item) => {
      const matchSearch =
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category.toLowerCase().includes(searchQuery.toLowerCase());
      const matchCat = selectedCategory === 'All' || item.category === selectedCategory;
      return matchSearch && matchCat;
    });
  }, [menuItems, searchQuery, selectedCategory]);

  const openAddModal = () => {
    setEditingItem(null);
    setItemName('');
    setItemCategory('Coffee');
    setItemPrice('');
    setItemImageUrl('');
    setErrorMsg(null);
    setIsModalOpen(true);
  };

  const openEditModal = (item: MenuItem) => {
    setEditingItem(item);
    setItemName(item.name);
    setItemCategory(item.category);
    setItemPrice(item.price.toString());
    setItemImageUrl(item.imageUrl || '');
    setErrorMsg(null);
    setIsModalOpen(true);
  };

  const handleSaveItem = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!itemName.trim()) {
      setErrorMsg('Item name is required.');
      return;
    }
    if (!itemCategory.trim()) {
      setErrorMsg('Category is required.');
      return;
    }
    const priceNum = parseFloat(itemPrice);
    if (isNaN(priceNum) || priceNum < 0) {
      setErrorMsg('Price must be a valid non-negative number in ETB.');
      return;
    }

    setSubmitting(true);
    try {
      if (editingItem) {
        await updateMenuItem(editingItem.id, {
          name: itemName.trim(),
          category: itemCategory.trim(),
          price: priceNum,
          imageUrl: itemImageUrl.trim(),
        });
        setSuccessMsg(`"${itemName.trim()}" updated successfully.`);
      } else {
        await addMenuItem({
          name: itemName.trim(),
          category: itemCategory.trim(),
          price: priceNum,
          imageUrl: itemImageUrl.trim(),
          isAvailable: true,
        });
        setSuccessMsg(`"${itemName.trim()}" added to menu.`);
      }
      setIsModalOpen(false);
      setTimeout(() => setSuccessMsg(null), 3000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to save menu item.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggle = async (item: MenuItem) => {
    try {
      await toggleAvailability(item.id, item.isAvailable);
    } catch (err: any) {
      alert(err.message || 'Failed to toggle availability.');
    }
  };

  const handleDelete = async () => {
    if (!deletingItem) return;
    setSubmitting(true);
    try {
      await deleteMenuItem(deletingItem.id);
      setSuccessMsg(`"${deletingItem.name}" deleted from menu.`);
      setDeletingItem(null);
      setTimeout(() => setSuccessMsg(null), 3000);
    } catch (err: any) {
      alert(err.message || 'Failed to delete item.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-serif text-[#3A2010]">
            Menu Management
          </h1>
          <p className="text-sm text-[#7D6352] mt-1">
            Configure food and beverage catalog, ETB pricing, image previews, and live availability
          </p>
        </div>
        <button
          onClick={openAddModal}
          className="flex items-center gap-2 px-4 py-2.5 bg-[#4A2E18] hover:bg-[#38200F] text-[#FFFDF9] font-bold text-xs rounded-xl shadow-md transition-all self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>+ Add Menu Item</span>
        </button>
      </div>

      {/* Success Notification */}
      {successMsg && (
        <div className="mb-6 p-3.5 bg-[#EDF7EE] border border-[#C6E6C8] rounded-xl text-xs text-[#28662F] flex items-center gap-2 font-medium">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-[#FFFDF9] border border-[#EADBCE] rounded-2xl p-4 mb-6 shadow-2xs flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-[#A89078]" />
          <input
            type="text"
            placeholder="Search items by name or category..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-[#FDFBF7] border border-[#D9C8B5] rounded-xl text-xs text-[#3A2010] placeholder-[#B5A08E] focus:outline-none"
          />
        </div>

        {/* Categories Bar */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 max-w-full">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 text-xs rounded-xl font-medium shrink-0 transition-colors ${
                selectedCategory === cat
                  ? 'bg-[#4A2E18] text-[#FFFDF9]'
                  : 'bg-[#F2E8DC] text-[#6B4226] hover:bg-[#EADBCE]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Loading state */}
      {loading && (
        <div className="text-center py-16">
          <div className="inline-block w-8 h-8 border-4 border-[#8C6D53]/20 border-t-[#8C6D53] rounded-full animate-spin mb-3" />
          <p className="text-xs text-[#8C6D53]">Loading menu items...</p>
        </div>
      )}

      {/* Menu Grid */}
      {!loading && (
        <>
          {filteredItems.length === 0 ? (
            <div className="text-center py-16 bg-[#FFFDF9] border border-[#EADBCE] rounded-2xl p-6">
              <BookOpen className="w-12 h-12 text-[#CBB29C] mx-auto mb-3" />
              <h3 className="text-base font-bold text-[#3A2010]">
                {menuItems.length === 0 ? 'No menu items yet' : 'No items match your search'}
              </h3>
              <p className="text-xs text-[#8C6D53] mt-1 max-w-sm mx-auto mb-4">
                {menuItems.length === 0
                  ? 'Add your first coffee, tea, pastry, or dish to start receiving orders.'
                  : 'Try selecting "All" categories or adjusting your search term.'}
              </p>
              {menuItems.length === 0 && (
                <button
                  onClick={openAddModal}
                  className="px-4 py-2 bg-[#4A2E18] text-white text-xs font-bold rounded-xl shadow-xs"
                >
                  + Add First Menu Item
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredItems.map((item) => (
                <div
                  key={item.id}
                  className={`bg-[#FFFDF9] border rounded-2xl overflow-hidden shadow-xs hover:shadow-sm transition-all flex flex-col justify-between ${
                    item.isAvailable
                      ? 'border-[#EADBCE]'
                      : 'border-[#E0D5C7] opacity-80 bg-[#FAF7F2]'
                  }`}
                >
                  <div>
                    {/* Item Image with Exact URL Preview */}
                    <div className="p-3 bg-[#FAF5EF] border-b border-[#EADBCE]">
                      <ImagePreview
                        url={item.imageUrl}
                        altText={item.name}
                        className="w-full h-36"
                      />
                    </div>

                    {/* Content */}
                    <div className="p-4 space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <span className="text-[10px] font-bold uppercase tracking-wider text-[#8C6D53]">
                            {item.category}
                          </span>
                          <h3 className="text-sm font-bold text-[#3A2010] mt-0.5 leading-snug">
                            {item.name}
                          </h3>
                        </div>
                        <span className="font-mono font-bold text-sm text-[#4A2E18] shrink-0">
                          ETB {item.price.toFixed(2)}
                        </span>
                      </div>

                      {/* Availability Indicator */}
                      <div className="pt-2 flex items-center justify-between">
                        <span
                          className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            item.isAvailable
                              ? 'bg-[#EDF7EE] text-[#28662F] border border-[#C6E6C8]'
                              : 'bg-[#F2E8DC] text-[#7D6352] border border-[#D9C8B5]'
                          }`}
                        >
                          <span
                            className={`w-1.5 h-1.5 rounded-full ${
                              item.isAvailable ? 'bg-[#34A853]' : 'bg-[#9E826C]'
                            }`}
                          />
                          {item.isAvailable ? 'Available' : 'Unavailable'}
                        </span>

                        {/* Quick Toggle Button */}
                        <button
                          type="button"
                          onClick={() => handleToggle(item)}
                          className="text-xs font-semibold text-[#8C5835] hover:text-[#4A2E18] flex items-center gap-1"
                          title="Toggle available for new orders"
                        >
                          {item.isAvailable ? (
                            <ToggleRight className="w-5 h-5 text-[#34A853]" />
                          ) : (
                            <ToggleLeft className="w-5 h-5 text-[#9E826C]" />
                          )}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Actions Bar */}
                  <div className="p-3 border-t border-[#EADBCE] bg-[#FDFBF7] flex items-center justify-end gap-2">
                    <button
                      onClick={() => openEditModal(item)}
                      className="p-1.5 text-[#6B4226] hover:bg-[#F2E8DC] rounded-lg transition-colors flex items-center gap-1 text-xs font-medium"
                      title="Edit item"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Edit</span>
                    </button>
                    <button
                      onClick={() => setDeletingItem(item)}
                      className="p-1.5 text-[#A63A24] hover:bg-[#FDF0ED] rounded-lg transition-colors flex items-center gap-1 text-xs font-medium"
                      title="Delete item"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {/* Add / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-[#FFFDF9] border border-[#EADBCE] rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
            <div className="px-6 py-4 border-b border-[#EADBCE] flex items-center justify-between bg-[#FDF8F2]">
              <h2 className="text-base font-bold font-serif text-[#3A2010]">
                {editingItem ? 'Edit Menu Item' : 'Add New Menu Item'}
              </h2>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-[#9E826C] hover:text-[#3A2010] p-1.5 rounded-lg hover:bg-[#F2E8DC]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveItem} className="p-6 space-y-4 overflow-y-auto">
              {errorMsg && (
                <div className="p-3 bg-[#FDF0ED] border border-[#F5C6BA] rounded-xl text-xs text-[#A63A24] flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* Item Name */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#6B4226] mb-1">
                  Item Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Macchiato"
                  value={itemName}
                  onChange={(e) => setItemName(e.target.value)}
                  className="w-full px-3.5 py-2 bg-white border border-[#D9C8B5] rounded-xl text-xs font-semibold text-[#3A2010] focus:outline-none focus:ring-1 focus:ring-[#8C5835]"
                />
              </div>

              {/* Category */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#6B4226] mb-1">
                  Category *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Coffee"
                  value={itemCategory}
                  onChange={(e) => setItemCategory(e.target.value)}
                  list="common-categories"
                  className="w-full px-3.5 py-2 bg-white border border-[#D9C8B5] rounded-xl text-xs font-semibold text-[#3A2010] focus:outline-none focus:ring-1 focus:ring-[#8C5835]"
                />
                <datalist id="common-categories">
                  {commonCategories.map((c) => (
                    <option key={c} value={c} />
                  ))}
                </datalist>
              </div>

              {/* Price in ETB */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#6B4226] mb-1">
                  Price in ETB *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-xs font-bold text-[#8C6D53]">
                    ETB
                  </div>
                  <input
                    type="number"
                    step="any"
                    min="0"
                    required
                    placeholder="80"
                    value={itemPrice}
                    onChange={(e) => setItemPrice(e.target.value)}
                    className="w-full pl-12 pr-3.5 py-2 bg-white border border-[#D9C8B5] rounded-xl text-xs font-mono font-bold text-[#3A2010] focus:outline-none focus:ring-1 focus:ring-[#8C5835]"
                  />
                </div>
              </div>

              {/* Image URL Input & Exact Preview */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#6B4226] mb-1">
                  Image URL (Public direct link)
                </label>
                <input
                  type="url"
                  placeholder="https://images.unsplash.com/photo-..."
                  value={itemImageUrl}
                  onChange={(e) => setItemImageUrl(e.target.value)}
                  className="w-full px-3.5 py-2 bg-white border border-[#D9C8B5] rounded-xl text-xs text-[#3A2010] focus:outline-none focus:ring-1 focus:ring-[#8C5835]"
                />
                <p className="text-[11px] text-[#8C6D53] mt-1">
                  Paste a direct web image URL. Left empty until entered.
                </p>

                {/* EXACT LIVE PREVIEW */}
                <div className="mt-3">
                  <span className="block text-[11px] font-bold text-[#6B4226] mb-1">
                    Live URL Preview:
                  </span>
                  <ImagePreview
                    url={itemImageUrl}
                    altText="Menu Item Preview"
                    className="w-full h-32"
                  />
                </div>
              </div>

              {/* Form Buttons */}
              <div className="pt-3 border-t border-[#EADBCE] flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-[#7D6352] hover:bg-[#F2E8DC] rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 bg-[#4A2E18] hover:bg-[#38200F] text-[#FFFDF9] text-xs font-bold rounded-xl shadow-xs disabled:opacity-50 flex items-center gap-2 cursor-pointer"
                >
                  {submitting ? (
                    <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      <span>{editingItem ? 'Save Changes' : 'Create Item'}</span>
                    </>
                  )}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deletingItem && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#FFFDF9] border border-[#EADBCE] rounded-2xl max-w-sm w-full p-6 shadow-2xl">
            <h3 className="text-base font-bold text-[#3A2010] mb-2">
              Delete Menu Item?
            </h3>
            <p className="text-xs text-[#7D6352] mb-5">
              Are you sure you want to delete <strong>"{deletingItem.name}"</strong>? Historical orders will retain their snapshots, but this item will no longer appear on the menu.
            </p>
            <div className="flex justify-end gap-2.5">
              <button
                onClick={() => setDeletingItem(null)}
                className="px-4 py-2 text-xs font-medium text-[#7D6352] hover:bg-[#F2E8DC] rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                disabled={submitting}
                className="px-4 py-2 text-xs font-bold bg-[#A63A24] text-white hover:bg-[#8C2E1A] rounded-xl shadow-sm"
              >
                Delete Item
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
