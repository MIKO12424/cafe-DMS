import React, { useState } from 'react';
import { Coffee, Eye, EyeOff, Lock, Mail, Store, AlertCircle, CheckCircle2, ArrowRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import loginBg from '../assets/images/login_bg_1791560562784.jpg';

export const AuthPage: React.FC = () => {
  const { login, register, resetPassword } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [isForgotPassword, setIsForgotPassword] = useState(false);

  // Form states
  const [restaurantName, setRestaurantName] = useState('');
  const [managerName, setManagerName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Status feedback
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);

    // Validation
    if (!email.trim()) {
      setError('Please enter your email address.');
      return;
    }

    if (isForgotPassword) {
      setSubmitting(true);
      try {
        await resetPassword(email.trim());
        setSuccessMessage('Password reset email sent. Please check your inbox.');
      } catch (err: any) {
        setError(err.message || 'Failed to send password reset email.');
      } finally {
        setSubmitting(false);
      }
      return;
    }

    if (!password) {
      setError('Please enter your password.');
      return;
    }

    if (isLogin) {
      setSubmitting(true);
      try {
        await login(email.trim(), password);
      } catch (err: any) {
        if (err.code === 'auth/invalid-credential' || err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password') {
          setError('Invalid email or password. Please check your credentials.');
        } else if (err.code === 'auth/operation-not-allowed') {
          setError('Email/Password provider is not yet enabled in your Firebase Console (Authentication > Sign-in method). Please enable it to sign in.');
        } else {
          setError(err.message || 'Login failed. Please try again.');
        }
      } finally {
        setSubmitting(false);
      }
    } else {
      // Registration validation
      if (!restaurantName.trim()) {
        setError('Please enter your restaurant or café name.');
        return;
      }
      if (!managerName.trim()) {
        setError('Please enter the manager or owner name.');
        return;
      }
      if (password.length < 6) {
        setError('Password must be at least 6 characters.');
        return;
      }
      if (password !== confirmPassword) {
        setError('Passwords do not match. Please verify your password.');
        return;
      }

      setSubmitting(true);
      try {
        await register(restaurantName.trim(), managerName.trim(), email.trim(), password);
      } catch (err: any) {
        if (err.code === 'auth/email-already-in-use') {
          setError('This email is already registered. Please log in instead.');
        } else if (err.code === 'auth/operation-not-allowed') {
          setError('Email/Password sign-in is not yet enabled in your Firebase Console (Authentication > Sign-in method). Please enable it to create accounts.');
        } else {
          setError(err.message || 'Registration failed. Please try again.');
        }
      } finally {
        setSubmitting(false);
      }
    }
  };

  return (
    <div 
      className="relative min-h-screen w-full flex flex-col justify-center py-12 sm:px-6 lg:px-8 text-[#2D1B0E] selection:bg-[#E2CEBC] bg-cover bg-center bg-no-repeat overflow-x-hidden"
      style={{
        backgroundImage: `url(${loginBg})`,
        backgroundColor: '#F5EFE6',
      }}
    >
      {/* Soft warm tint overlay to ensure maximum readability and focus on centered login card */}
      <div className="absolute inset-0 bg-[#FBF7F0]/30 backdrop-blur-[1px] pointer-events-none" />

      {/* Brand Logo & Title */}
      <div className="relative z-10 sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-[#4A2E18] text-[#FDFBF7] shadow-lg shadow-[#4A2E18]/20 mb-4 transition-transform hover:scale-105">
          <Coffee className="w-9 h-9" strokeWidth={2.2} />
        </div>
        <h1 className="text-3xl font-extrabold tracking-tight text-[#3A2010] font-serif drop-shadow-2xs">
          CafeDMS
        </h1>
        <p className="mt-1 text-sm text-[#7D6352] font-semibold">
          Complete Restaurant Management System
        </p>
      </div>

      <div className="relative z-10 mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4 sm:px-0">
        <div className="bg-[#FFFDF9]/95 backdrop-blur-md py-8 px-6 sm:px-10 shadow-2xl shadow-[#4A2E18]/12 rounded-3xl border border-[#EADBCE]/90">
          
          {/* Form Header */}
          <div className="mb-6">
            <h2 className="text-xl font-bold text-[#3A2010]">
              {isForgotPassword
                ? 'Reset Password'
                : isLogin
                ? 'Welcome Back'
                : 'Register Your Restaurant'}
            </h2>
            <p className="text-xs text-[#8C6D53] mt-1">
              {isForgotPassword
                ? 'Enter your email address to receive a reset link'
                : isLogin
                ? 'Log in to manage your dining tables, orders, and payments'
                : 'Create a dedicated workspace for your café or restaurant'}
            </p>
          </div>

          {/* Feedback Messages */}
          {error && (
            <div className="mb-5 flex items-start gap-3 p-3.5 bg-[#FDF0ED] border border-[#F5C6BA] rounded-xl text-xs text-[#A63A24]">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <div className="flex-1 font-medium">{error}</div>
            </div>
          )}

          {successMessage && (
            <div className="mb-5 flex items-start gap-3 p-3.5 bg-[#EDF7EE] border border-[#C6E6C8] rounded-xl text-xs text-[#28662F]">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
              <div className="flex-1 font-medium">{successMessage}</div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Restaurant Name (Registration only) */}
            {!isLogin && !isForgotPassword && (
              <>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#634832] mb-1.5">
                    Restaurant or Café Name
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#9E826C]">
                      <Store className="w-4 h-4" />
                    </div>
                    <input
                      type="text"
                      required
                      value={restaurantName}
                      onChange={(e) => setRestaurantName(e.target.value)}
                      placeholder="e.g. Blue Nile Café & Roastery"
                      className="w-full pl-10 pr-3.5 py-2.5 bg-[#FDFBF7] border border-[#D9C8B5] rounded-xl text-sm text-[#2D1B0E] placeholder-[#B5A08E] focus:outline-none focus:ring-2 focus:ring-[#8C5835]/30 focus:border-[#6B4226] transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#634832] mb-1.5">
                    Manager / Owner Name
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#9E826C]">
                      <Store className="w-4 h-4" />
                    </div>
                    <input
                      type="text"
                      required
                      value={managerName}
                      onChange={(e) => setManagerName(e.target.value)}
                      placeholder="e.g. Abebe Kebede (Manager)"
                      className="w-full pl-10 pr-3.5 py-2.5 bg-[#FDFBF7] border border-[#D9C8B5] rounded-xl text-sm text-[#2D1B0E] placeholder-[#B5A08E] focus:outline-none focus:ring-2 focus:ring-[#8C5835]/30 focus:border-[#6B4226] transition-all"
                    />
                  </div>
                </div>
              </>
            )}

            {/* Email Address */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#634832] mb-1.5">
                {isLogin ? 'Manager / Staff Email Address' : 'Manager Email Address'}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#9E826C]">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="owner@restaurant.com"
                  className="w-full pl-10 pr-3.5 py-2.5 bg-[#FDFBF7] border border-[#D9C8B5] rounded-xl text-sm text-[#2D1B0E] placeholder-[#B5A08E] focus:outline-none focus:ring-2 focus:ring-[#8C5835]/30 focus:border-[#6B4226] transition-all"
                />
              </div>
            </div>

            {/* Password */}
            {!isForgotPassword && (
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#634832]">
                    Password
                  </label>
                  {isLogin && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsForgotPassword(true);
                        setError(null);
                        setSuccessMessage(null);
                      }}
                      className="text-xs font-medium text-[#8C5835] hover:text-[#4A2E18] hover:underline"
                    >
                      Forgot password?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#9E826C]">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-10 py-2.5 bg-[#FDFBF7] border border-[#D9C8B5] rounded-xl text-sm text-[#2D1B0E] placeholder-[#B5A08E] focus:outline-none focus:ring-2 focus:ring-[#8C5835]/30 focus:border-[#6B4226] transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#9E826C] hover:text-[#4A2E18]"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {/* Confirm Password (Registration only) */}
            {!isLogin && !isForgotPassword && (
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#634832] mb-1.5">
                  Confirm Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#9E826C]">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showConfirmPassword ? 'text' : 'password'}
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-10 py-2.5 bg-[#FDFBF7] border border-[#D9C8B5] rounded-xl text-sm text-[#2D1B0E] placeholder-[#B5A08E] focus:outline-none focus:ring-2 focus:ring-[#8C5835]/30 focus:border-[#6B4226] transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#9E826C] hover:text-[#4A2E18]"
                    aria-label={showConfirmPassword ? 'Hide password' : 'Show password'}
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {/* Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={submitting}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-[#4A2E18] hover:bg-[#38200F] text-[#FDFBF7] font-semibold text-sm rounded-xl shadow-md shadow-[#4A2E18]/20 transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#4A2E18] disabled:opacity-60"
              >
                {submitting ? (
                  <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <span>
                      {isForgotPassword
                        ? 'Send Reset Link'
                        : isLogin
                        ? 'Log In'
                        : 'Create Account'}
                    </span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Toggle Links */}
          <div className="mt-6 pt-5 border-t border-[#EADBCE] text-center text-xs text-[#7D6352]">
            {isForgotPassword ? (
              <button
                type="button"
                onClick={() => {
                  setIsForgotPassword(false);
                  setIsLogin(true);
                  setError(null);
                  setSuccessMessage(null);
                }}
                className="font-semibold text-[#8C5835] hover:text-[#4A2E18] hover:underline"
              >
                Back to Log In
              </button>
            ) : isLogin ? (
              <p>
                Don't have a restaurant account?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setIsLogin(false);
                    setError(null);
                    setSuccessMessage(null);
                  }}
                  className="font-semibold text-[#8C5835] hover:text-[#4A2E18] hover:underline ml-1"
                >
                  Create Account
                </button>
              </p>
            ) : (
              <p>
                Already registered?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setIsLogin(true);
                    setError(null);
                    setSuccessMessage(null);
                  }}
                  className="font-semibold text-[#8C5835] hover:text-[#4A2E18] hover:underline ml-1"
                >
                  Log In
                </button>
              </p>
            )}
          </div>

        </div>
      </div>
    </div>
  );
};
