import React, { useState } from 'react';
import { 
  Store, 
  User, 
  Sliders, 
  Coins, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles,
  ShieldCheck 
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useRestaurantData } from '../context/RestaurantDataContext';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase/config';

export const SettingsPage: React.FC = () => {
  const { userProfile, restaurant, currentUser, refreshProfile } = useAuth();
  const { tables, updateTableConfig, addMenuItem, menuItems } = useRestaurantData();

  const [restaurantName, setRestaurantName] = useState(restaurant?.name || '');
  const [tableCountInput, setTableCountInput] = useState(tables.length || 8);
  const [saving, setSaving] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  React.useEffect(() => {
    if (restaurant?.name) setRestaurantName(restaurant.name);
    if (tables.length) setTableCountInput(tables.length);
  }, [restaurant, tables]);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!restaurant?.id) return;
    setErrorMsg(null);
    setFeedbackMsg(null);
    setSaving(true);

    try {
      // 1. Update restaurant name if changed
      if (restaurantName.trim() !== restaurant.name) {
        await updateDoc(doc(db, 'restaurants', restaurant.id), {
          name: restaurantName.trim(),
        });
        if (currentUser) {
          await updateDoc(doc(db, 'users', currentUser.uid), {
            restaurantName: restaurantName.trim(),
          });
        }
        await refreshProfile();
      }

      // 2. Update table count if changed
      if (tableCountInput !== tables.length) {
        await updateTableConfig(tableCountInput);
      }

      setFeedbackMsg('Restaurant settings saved successfully.');
      setTimeout(() => setFeedbackMsg(null), 3500);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to update settings.');
    } finally {
      setSaving(false);
    }
  };

  const handleSeedSampleMenu = async () => {
    if (menuItems.length > 0) {
      if (!confirm('You already have menu items. Do you want to add starter items like Macchiato and Croissants?')) {
        return;
      }
    }
    setSeeding(true);
    try {
      const samples = [
        { name: 'Macchiato', category: 'Coffee', price: 80, imageUrl: 'https://images.unsplash.com/photo-1541167760496-1628856ab772?w=500&auto=format&fit=crop&q=60', isAvailable: true },
        { name: 'Espresso Single', category: 'Coffee', price: 60, imageUrl: 'https://images.unsplash.com/photo-1510591509098-f4fdc6d0ff04?w=500&auto=format&fit=crop&q=60', isAvailable: true },
        { name: 'Café Latte', category: 'Coffee', price: 110, imageUrl: 'https://images.unsplash.com/photo-1534778101976-62847782c213?w=500&auto=format&fit=crop&q=60', isAvailable: true },
        { name: 'Ethiopian Spiced Tea', category: 'Tea', price: 50, imageUrl: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=500&auto=format&fit=crop&q=60', isAvailable: true },
        { name: 'Fresh Butter Croissant', category: 'Pastry', price: 95, imageUrl: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=500&auto=format&fit=crop&q=60', isAvailable: true },
        { name: 'Doro Club Sandwich', category: 'Lunch', price: 240, imageUrl: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=500&auto=format&fit=crop&q=60', isAvailable: true },
      ];

      for (const item of samples) {
        await addMenuItem(item);
      }
      setFeedbackMsg('Starter menu items added successfully.');
      setTimeout(() => setFeedbackMsg(null), 3500);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to seed sample items.');
    } finally {
      setSeeding(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      {/* Page Header */}
      <div className="mb-6">
        <h1 className="text-2xl sm:text-3xl font-bold font-serif text-[#3A2010]">
          Settings
        </h1>
        <p className="text-sm text-[#7D6352] mt-1">
          Manage restaurant preferences, dining table numbers, and owner profile
        </p>
      </div>

      {feedbackMsg && (
        <div className="mb-6 p-3.5 bg-[#EDF7EE] border border-[#C6E6C8] rounded-xl text-xs text-[#28662F] flex items-center gap-2 font-medium">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{feedbackMsg}</span>
        </div>
      )}

      {errorMsg && (
        <div className="mb-6 p-3.5 bg-[#FDF0ED] border border-[#F5C6BA] rounded-xl text-xs text-[#A63A24] flex items-center gap-2 font-medium">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      <form onSubmit={handleSaveSettings} className="space-y-6">
        
        {/* Restaurant Profile Card */}
        <div className="bg-[#FFFDF9] border border-[#EADBCE] rounded-2xl p-6 shadow-xs">
          <div className="flex items-center gap-3 pb-4 border-b border-[#EADBCE] mb-4">
            <div className="w-9 h-9 rounded-xl bg-[#FAF2E8] text-[#4A2E18] flex items-center justify-center">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-[#3A2010]">
                Restaurant Information
              </h2>
              <p className="text-[11px] text-[#8C6D53]">
                Your brand identity and public venue name
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#6B4226] mb-1.5">
                Restaurant or Café Name
              </label>
              <input
                type="text"
                required
                value={restaurantName}
                onChange={(e) => setRestaurantName(e.target.value)}
                className="w-full px-4 py-2.5 bg-[#FDFBF7] border border-[#D9C8B5] rounded-xl text-sm font-semibold text-[#3A2010] focus:outline-none focus:ring-1 focus:ring-[#8C5835]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#6B4226] mb-1.5">
                  Currency
                </label>
                <div className="flex items-center gap-2 px-3.5 py-2.5 bg-[#F7F2EA] border border-[#E0D5C7] rounded-xl text-xs font-bold text-[#4A2E18]">
                  <Coins className="w-4 h-4 text-[#8C5835]" />
                  <span>ETB (Ethiopian Birr)</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#6B4226] mb-1.5">
                  Total Dining Tables
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min={1}
                    max={50}
                    value={tableCountInput}
                    onChange={(e) => setTableCountInput(parseInt(e.target.value) || 1)}
                    className="w-full px-3.5 py-2.5 bg-[#FDFBF7] border border-[#D9C8B5] rounded-xl text-xs font-semibold text-[#3A2010] focus:outline-none focus:ring-1 focus:ring-[#8C5835]"
                  />
                  <span className="text-xs text-[#8C6D53] shrink-0 font-medium">
                    tables
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Owner/Manager Account Information */}
        <div className="bg-[#FFFDF9] border border-[#EADBCE] rounded-2xl p-6 shadow-xs">
          <div className="flex items-center gap-3 pb-4 border-b border-[#EADBCE] mb-4">
            <div className="w-9 h-9 rounded-xl bg-[#FAF2E8] text-[#4A2E18] flex items-center justify-center">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-[#3A2010]">
                Manager & Account Information
              </h2>
              <p className="text-[11px] text-[#8C6D53]">
                Authentication credentials, manager profile, and security isolation details
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="bg-[#FAF5EF] p-3 rounded-xl border border-[#EADBCE]">
              <span className="text-[10px] font-bold uppercase text-[#8C6D53] block">
                Manager / Owner Name
              </span>
              <span className="font-semibold text-[#3A2010] mt-0.5 block truncate">
                {userProfile?.managerName || restaurant?.managerName || 'Restaurant Manager'}
              </span>
            </div>

            <div className="bg-[#FAF5EF] p-3 rounded-xl border border-[#EADBCE]">
              <span className="text-[10px] font-bold uppercase text-[#8C6D53] block">
                Account Email
              </span>
              <span className="font-semibold text-[#3A2010] mt-0.5 block truncate">
                {userProfile?.email || currentUser?.email || '—'}
              </span>
            </div>

            <div className="bg-[#FAF5EF] p-3 rounded-xl border border-[#EADBCE]">
              <span className="text-[10px] font-bold uppercase text-[#8C6D53] block">
                Restaurant ID (Tenant Partition)
              </span>
              <span className="font-mono text-[#4A2E18] font-bold mt-0.5 block truncate">
                {restaurant?.id || '—'}
              </span>
            </div>

            <div className="bg-[#FAF5EF] p-3 rounded-xl border border-[#EADBCE]">
              <span className="text-[10px] font-bold uppercase text-[#8C6D53] block">
                Access Level
              </span>
              <span className="inline-flex items-center gap-1 font-bold text-[#28662F] mt-0.5">
                <ShieldCheck className="w-3.5 h-3.5" />
                {userProfile?.role === 'manager' || userProfile?.role === 'owner' ? 'Manager (Authorized Admin)' : 'Staff Member'}
              </span>
            </div>
          </div>
        </div>

        {/* Payment Security Lock Information */}
        <div className="bg-[#FFFDF9] border border-[#EADBCE] rounded-2xl p-6 shadow-xs">
          <div className="flex items-center gap-3 pb-4 border-b border-[#EADBCE] mb-4">
            <div className="w-9 h-9 rounded-xl bg-[#FAF2E8] text-[#4A2E18] flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-[#8C5835]" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-[#3A2010]">
                Payment Option Security Lock
              </h2>
              <p className="text-[11px] text-[#8C6D53]">
                Manager authorization protection for financial settlements and ledger
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="bg-[#FAF5EF] p-3 rounded-xl border border-[#EADBCE]">
              <span className="text-[10px] font-bold uppercase text-[#8C6D53] block">
                Security Lock Status
              </span>
              <span className="inline-flex items-center gap-1.5 font-bold text-[#28662F] mt-1 text-sm">
                <span className="w-2 h-2 rounded-full bg-[#34A853]" />
                LOCKED (Active)
              </span>
            </div>

            <div className="bg-[#FAF5EF] p-3 rounded-xl border border-[#EADBCE]">
              <span className="text-[10px] font-bold uppercase text-[#8C6D53] block">
                Authorization PIN
              </span>
              <span className="font-mono text-base font-bold text-[#4A2E18] mt-0.5 block tracking-widest">
                ••••••
              </span>
            </div>
          </div>
          <p className="text-[11px] text-[#7D6352] mt-3">
            Staff and managers must enter the authorization PIN to unlock the Payments section and view financial collections.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
          {/* Starter Menu Seeder */}
          <button
            type="button"
            disabled={seeding}
            onClick={handleSeedSampleMenu}
            className="flex items-center gap-2 px-4 py-2.5 bg-[#F2E8DC] hover:bg-[#EADBCE] text-[#4A2E18] text-xs font-semibold rounded-xl border border-[#D9C8B5] transition-colors cursor-pointer self-start sm:self-auto"
          >
            <Sparkles className="w-4 h-4 text-[#8C5835]" />
            <span>{seeding ? 'Adding starter menu...' : 'Add Starter Café Items'}</span>
          </button>

          <button
            type="submit"
            disabled={saving}
            className="px-6 py-2.5 bg-[#4A2E18] hover:bg-[#38200F] text-[#FFFDF9] text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer self-end sm:self-auto"
          >
            {saving ? 'Saving...' : 'Save Settings'}
          </button>
        </div>

      </form>
    </div>
  );
};
