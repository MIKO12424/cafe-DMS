import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  UtensilsCrossed, 
  ShoppingBag, 
  Plus, 
  Receipt, 
  Clock, 
  ChevronRight, 
  Calendar,
  X
} from 'lucide-react';
import { useRestaurantData } from '../context/RestaurantDataContext';
import { Order, OrderType, PaymentStatus } from '../types';

interface ActiveOrdersPageProps {
  onOpenNewOrder: () => void;
  onOpenAddItems: (order: Order) => void;
  onOpenPayment: (order: Order) => void;
}

export const ActiveOrdersPage: React.FC<ActiveOrdersPageProps> = ({
  onOpenNewOrder,
  onOpenAddItems,
  onOpenPayment,
}) => {
  const { orders, loading } = useRestaurantData();

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | OrderType>('all');
  const [filterPayment, setFilterPayment] = useState<'all' | 'unpaid' | 'partial'>('all');

  // Selected Order for Detail Drawer
  const [inspectingOrder, setInspectingOrder] = useState<Order | null>(null);

  // Filter ONLY active orders (not completed / cancelled)
  const activeOrders = useMemo(() => {
    return orders.filter((o) => o.status === 'active');
  }, [orders]);

  const filteredOrders = useMemo(() => {
    return activeOrders.filter((o) => {
      // Search by order number or table name
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        !q ||
        o.orderNumber.toLowerCase().includes(q) ||
        (o.tableName && o.tableName.toLowerCase().includes(q));

      // Filter by order type
      const matchType = filterType === 'all' || o.orderType === filterType;

      // Filter by payment status
      const matchPayment = filterPayment === 'all' || o.paymentStatus === filterPayment;

      return matchSearch && matchType && matchPayment;
    });
  }, [activeOrders, searchQuery, filterType, filterPayment]);

  const formatDateTime = (isoString: string) => {
    try {
      const date = new Date(isoString);
      return date.toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return isoString;
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-serif text-[#3A2010]">
            Active Orders
          </h1>
          <p className="text-sm text-[#7D6352] mt-1">
            Orders currently in progress and pending full payment
          </p>
        </div>
        <button
          onClick={onOpenNewOrder}
          className="flex items-center gap-2 px-4 py-2.5 bg-[#4A2E18] hover:bg-[#38200F] text-[#FFFDF9] font-bold text-xs rounded-xl shadow-md transition-all self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>+ Add New Order</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-[#FFFDF9] border border-[#EADBCE] rounded-2xl p-4 mb-6 shadow-2xs space-y-3 sm:space-y-0 sm:flex sm:items-center sm:gap-4">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-[#A89078]" />
          <input
            type="text"
            placeholder="Search by order # (e.g. #1001) or table..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-[#FDFBF7] border border-[#D9C8B5] rounded-xl text-xs text-[#3A2010] placeholder-[#B5A08E] focus:outline-none focus:ring-1 focus:ring-[#8C5835]"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Type Filter */}
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value as any)}
            className="px-3 py-2 bg-[#FDFBF7] border border-[#D9C8B5] rounded-xl text-xs text-[#6B4226] font-medium focus:outline-none"
          >
            <option value="all">All Types</option>
            <option value="dine-in">Dine In</option>
            <option value="takeaway">Takeaway</option>
          </select>

          {/* Payment Status Filter */}
          <select
            value={filterPayment}
            onChange={(e) => setFilterPayment(e.target.value as any)}
            className="px-3 py-2 bg-[#FDFBF7] border border-[#D9C8B5] rounded-xl text-xs text-[#6B4226] font-medium focus:outline-none"
          >
            <option value="all">All Payment Statuses</option>
            <option value="unpaid">Unpaid</option>
            <option value="partial">Partially Paid</option>
          </select>
        </div>
      </div>

      {/* Loading state */}
      {loading && (
        <div className="text-center py-16">
          <div className="inline-block w-8 h-8 border-4 border-[#8C6D53]/20 border-t-[#8C6D53] rounded-full animate-spin mb-3" />
          <p className="text-xs text-[#8C6D53]">Loading active orders...</p>
        </div>
      )}

      {/* Orders List */}
      {!loading && (
        <>
          {filteredOrders.length === 0 ? (
            <div className="text-center py-16 bg-[#FFFDF9] border border-[#EADBCE] rounded-2xl">
              <ClipboardList className="w-12 h-12 text-[#CBB29C] mx-auto mb-3" />
              <h3 className="text-base font-bold text-[#3A2010]">
                No active orders found
              </h3>
              <p className="text-xs text-[#8C6D53] mt-1 max-w-sm mx-auto">
                {activeOrders.length === 0
                  ? 'There are currently no open orders in progress. Click "+ Add New Order" to start one.'
                  : 'No orders match your search and filter criteria.'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredOrders.map((order) => {
                const isDineIn = order.orderType === 'dine-in';
                const isPartial = order.paymentStatus === 'partial';

                return (
                  <div
                    key={order.id}
                    className="bg-[#FFFDF9] border border-[#EADBCE] hover:border-[#C4A992] rounded-2xl p-5 shadow-xs transition-all flex flex-col justify-between"
                  >
                    <div>
                      {/* Top Bar: Number & Badges */}
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <span className="text-base font-bold font-serif text-[#3A2010]">
                            {order.orderNumber}
                          </span>
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold ${
                              isDineIn
                                ? 'bg-[#F2E8DC] text-[#6B4226]'
                                : 'bg-[#EBF2F7] text-[#24547A]'
                            }`}
                          >
                            {isDineIn ? (
                              <UtensilsCrossed className="w-3 h-3" />
                            ) : (
                              <ShoppingBag className="w-3 h-3" />
                            )}
                            {isDineIn ? order.tableName || 'Dine In' : 'Takeaway'}
                          </span>
                        </div>

                        {/* Payment Status Badge */}
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            isPartial
                              ? 'bg-[#FFF3E0] text-[#B06014] border border-[#FFE0B2]'
                              : 'bg-[#FDF0ED] text-[#A63A24] border border-[#F5C6BA]'
                          }`}
                        >
                          {isPartial ? 'Partially Paid' : 'Unpaid'}
                        </span>
                      </div>

                      {/* Date & Items Count */}
                      <div className="flex items-center gap-3 text-[11px] text-[#8C6D53] mb-3">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-[#B59C86]" />
                          {formatDateTime(order.createdAt)}
                        </span>
                        <span>•</span>
                        <span>{order.items.reduce((acc, it) => acc + it.quantity, 0)} items</span>
                      </div>

                      {/* Items Preview */}
                      <div className="bg-[#FAF5EF] rounded-xl p-3 mb-4 space-y-1.5 text-xs max-h-28 overflow-y-auto">
                        {order.items.map((it, idx) => (
                          <div
                            key={idx}
                            className="flex justify-between items-center text-[#593E2B]"
                          >
                            <span className="truncate pr-2">
                              {it.quantity}× {it.name}
                            </span>
                            <span className="font-mono text-[#8C5835] font-semibold shrink-0">
                              ETB {it.subtotal.toFixed(2)}
                            </span>
                          </div>
                        ))}
                      </div>

                      {/* Financials Breakdown */}
                      <div className="space-y-1 text-xs border-t border-[#EADBCE]/80 pt-3">
                        <div className="flex justify-between text-[#7D6352]">
                          <span>Total:</span>
                          <span className="font-mono font-bold text-[#3A2010]">
                            ETB {order.totalAmount.toFixed(2)}
                          </span>
                        </div>
                        {order.amountPaid > 0 && (
                          <div className="flex justify-between text-[#28662F]">
                            <span>Paid:</span>
                            <span className="font-mono font-semibold">
                              ETB {order.amountPaid.toFixed(2)}
                            </span>
                          </div>
                        )}
                        <div className="flex justify-between text-[#A63A24] font-bold pt-1">
                          <span>Remaining Balance:</span>
                          <span className="font-mono text-sm">
                            ETB {order.remainingBalance.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="mt-4 pt-3 border-t border-[#EADBCE] grid grid-cols-2 gap-2">
                      <button
                        onClick={() => onOpenAddItems(order)}
                        className="py-2 px-3 bg-[#F2E8DC] hover:bg-[#EADBCE] text-[#4A2E18] text-xs font-bold rounded-xl transition-colors flex items-center justify-center gap-1 cursor-pointer"
                        title="Add items to this order"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>+ Items</span>
                      </button>
                      <button
                        onClick={() => onOpenPayment(order)}
                        className="py-2 px-3 bg-[#4A2E18] hover:bg-[#38200F] text-[#FFFDF9] text-xs font-bold rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1 cursor-pointer"
                        title="Record payment"
                      >
                        <Receipt className="w-3.5 h-3.5" />
                        <span>Save Payment</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}
    </div>
  );
};

// ClipboardList icon helper
function ClipboardList(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      fill="none"
      stroke="currentColor"
      viewBox="0 0 24 24"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="8" height="4" x="8" y="2" rx="1" ry="1" />
      <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" />
      <path d="M9 12h6" />
      <path d="M9 16h6" />
    </svg>
  );
}
