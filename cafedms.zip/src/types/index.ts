export type UserRole = 'manager' | 'owner' | 'staff';

export interface UserProfile {
  uid: string;
  email: string;
  managerName?: string;
  restaurantId: string;
  restaurantName: string;
  role: UserRole;
  createdAt: string;
}

export interface Restaurant {
  id: string;
  name: string;
  ownerId: string;
  ownerEmail: string;
  managerName?: string;
  currency: string;
  tableCount: number;
  createdAt: string;
}

export interface MenuItem {
  id: string;
  restaurantId: string;
  name: string;
  category: string;
  price: number;
  imageUrl: string;
  isAvailable: boolean;
  createdAt: string;
  updatedAt?: string;
}

export type TableStatus = 'available' | 'occupied';

export interface RestaurantTable {
  id: string;
  restaurantId: string;
  name: string;
  number: number;
  status: TableStatus;
  activeOrderId?: string;
  activeOrderNumber?: string;
}

export interface OrderItem {
  itemId: string;
  name: string;
  price: number; // frozen snapshot
  quantity: number;
  subtotal: number;
}

export type OrderType = 'dine-in' | 'takeaway';
export type PaymentStatus = 'unpaid' | 'partial' | 'paid';
export type OrderLifecycleStatus = 'active' | 'completed' | 'cancelled';

export interface Order {
  id: string;
  orderNumber: string;
  restaurantId: string;
  orderType: OrderType;
  tableId?: string;
  tableName?: string;
  items: OrderItem[];
  totalAmount: number;
  amountPaid: number;
  remainingBalance: number;
  paymentStatus: PaymentStatus;
  status: OrderLifecycleStatus;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export type PaymentMethod = 'Cash' | 'Telebirr' | 'CBE';

export interface PaymentRecord {
  id: string;
  restaurantId: string;
  orderId: string;
  orderNumber: string;
  tableName: string;
  method: PaymentMethod;
  amount: number;
  staffMember: string;
  createdAt: string;
}

export type NavigationTab = 
  | 'dashboard'
  | 'tables'
  | 'active-orders'
  | 'payments'
  | 'menu-management'
  | 'settings';
