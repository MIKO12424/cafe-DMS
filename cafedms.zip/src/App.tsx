/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Menu as MenuIcon, Coffee } from 'lucide-react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { RestaurantDataProvider, useRestaurantData } from './context/RestaurantDataContext';
import { Sidebar } from './components/Sidebar';
import { AuthPage } from './pages/AuthPage';
import { DashboardPage } from './pages/DashboardPage';
import { TablesPage } from './pages/TablesPage';
import { ActiveOrdersPage } from './pages/ActiveOrdersPage';
import { PaymentsPage } from './pages/PaymentsPage';
import { MenuManagementPage } from './pages/MenuManagementPage';
import { SettingsPage } from './pages/SettingsPage';
import { OrderModal } from './components/OrderModal';
import { AddItemsModal } from './components/AddItemsModal';
import { PaymentModal } from './components/PaymentModal';
import { NavigationTab, Order } from './types';

function MainApp() {
  const { currentUser, loading: authLoading } = useAuth();
  const [currentTab, setCurrentTab] = useState<NavigationTab>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Global Modals State
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [orderModalType, setOrderModalType] = useState<'dine-in' | 'takeaway'>('dine-in');
  const [orderModalTableId, setOrderModalTableId] = useState<string | undefined>(undefined);

  const [addItemsOrder, setAddItemsOrder] = useState<Order | null>(null);
  const [paymentOrder, setPaymentOrder] = useState<Order | null>(null);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-[#FBF7F0] flex flex-col items-center justify-center text-[#4A2E18]">
        <div className="w-12 h-12 rounded-2xl bg-[#4A2E18] text-[#FFFDF9] flex items-center justify-center shadow-lg mb-4 animate-bounce">
          <Coffee className="w-6 h-6" />
        </div>
        <p className="text-sm font-semibold tracking-wide text-[#7D6352]">
          Loading CafeDMS...
        </p>
      </div>
    );
  }

  if (!currentUser) {
    return <AuthPage />;
  }

  return (
    <RestaurantDataProvider>
      <MainLayout
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        mobileMenuOpen={mobileMenuOpen}
        setMobileMenuOpen={setMobileMenuOpen}
        isOrderModalOpen={isOrderModalOpen}
        setIsOrderModalOpen={setIsOrderModalOpen}
        orderModalType={orderModalType}
        setOrderModalType={setOrderModalType}
        orderModalTableId={orderModalTableId}
        setOrderModalTableId={setOrderModalTableId}
        addItemsOrder={addItemsOrder}
        setAddItemsOrder={setAddItemsOrder}
        paymentOrder={paymentOrder}
        setPaymentOrder={setPaymentOrder}
      />
    </RestaurantDataProvider>
  );
}

function MainLayout({
  currentTab,
  setCurrentTab,
  mobileMenuOpen,
  setMobileMenuOpen,
  isOrderModalOpen,
  setIsOrderModalOpen,
  orderModalType,
  setOrderModalType,
  orderModalTableId,
  setOrderModalTableId,
  addItemsOrder,
  setAddItemsOrder,
  paymentOrder,
  setPaymentOrder,
}: {
  currentTab: NavigationTab;
  setCurrentTab: (tab: NavigationTab) => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
  isOrderModalOpen: boolean;
  setIsOrderModalOpen: (open: boolean) => void;
  orderModalType: 'dine-in' | 'takeaway';
  setOrderModalType: (type: 'dine-in' | 'takeaway') => void;
  orderModalTableId?: string;
  setOrderModalTableId: (id?: string) => void;
  addItemsOrder: Order | null;
  setAddItemsOrder: (order: Order | null) => void;
  paymentOrder: Order | null;
  setPaymentOrder: (order: Order | null) => void;
}) {
  const { orders } = useRestaurantData();
  const activeOrdersCount = orders.filter((o) => o.status === 'active').length;

  const handleOpenNewOrder = (type: 'dine-in' | 'takeaway' = 'dine-in', tableId?: string) => {
    setOrderModalType(type);
    setOrderModalTableId(tableId);
    setIsOrderModalOpen(true);
  };

  const handleStartDineInForTable = (tableId: string) => {
    handleOpenNewOrder('dine-in', tableId);
  };

  return (
    <div className="min-h-screen bg-[#FBF7F0] flex flex-col md:flex-row text-[#2D1B0E]">
      {/* Sidebar Navigation */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
        activeOrdersCount={activeOrdersCount}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen overflow-x-hidden">
        {/* Mobile Header */}
        <header className="md:hidden bg-[#FFFDF9] border-b border-[#EADBCE] px-4 py-3 flex items-center justify-between sticky top-0 z-30 shadow-2xs">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="p-1.5 text-[#4A2E18] hover:bg-[#F2E8DC] rounded-lg"
              aria-label="Open navigation menu"
            >
              <MenuIcon className="w-5 h-5" />
            </button>
            <span className="font-serif font-bold text-base text-[#3A2010]">
              CafeDMS
            </span>
          </div>
          <span className="text-xs font-semibold uppercase tracking-wider text-[#8C6D53]">
            {currentTab.replace('-', ' ')}
          </span>
        </header>

        {/* Page View Container */}
        <main className="flex-1 overflow-y-auto">
          {currentTab === 'dashboard' && (
            <DashboardPage
              onOpenNewOrder={() => handleOpenNewOrder('dine-in')}
              onNavigateToTables={() => setCurrentTab('tables')}
              onNavigateToOrders={() => setCurrentTab('active-orders')}
            />
          )}

          {currentTab === 'tables' && (
            <TablesPage
              onStartDineInOrder={handleStartDineInForTable}
              onOpenOrderDetails={(order) => setAddItemsOrder(order)}
              onOpenAddItems={(order) => setAddItemsOrder(order)}
              onOpenPayment={(order) => setPaymentOrder(order)}
            />
          )}

          {currentTab === 'active-orders' && (
            <ActiveOrdersPage
              onOpenNewOrder={() => handleOpenNewOrder('dine-in')}
              onOpenAddItems={(order) => setAddItemsOrder(order)}
              onOpenPayment={(order) => setPaymentOrder(order)}
            />
          )}

          {currentTab === 'payments' && (
            <PaymentsPage
              onOpenPaymentForOrder={(order) => setPaymentOrder(order)}
            />
          )}

          {currentTab === 'menu-management' && <MenuManagementPage />}

          {currentTab === 'settings' && <SettingsPage />}
        </main>
      </div>

      {/* Add New Order Modal (Dine In / Takeaway) */}
      <OrderModal
        isOpen={isOrderModalOpen}
        onClose={() => setIsOrderModalOpen(false)}
        initialType={orderModalType}
        initialTableId={orderModalTableId}
        onSwitchToAddItems={(existingOrder) => {
          setIsOrderModalOpen(false);
          setAddItemsOrder(existingOrder);
        }}
      />

      {/* Add Items to Existing Active Order Modal */}
      <AddItemsModal
        isOpen={!!addItemsOrder}
        order={addItemsOrder}
        onClose={() => setAddItemsOrder(null)}
      />

      {/* Save Payment Modal */}
      <PaymentModal
        isOpen={!!paymentOrder}
        order={paymentOrder}
        onClose={() => setPaymentOrder(null)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
