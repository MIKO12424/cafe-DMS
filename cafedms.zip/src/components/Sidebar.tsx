import React from 'react';
import { 
  LayoutDashboard, 
  UtensilsCrossed, 
  ClipboardList, 
  Receipt, 
  BookOpen, 
  Settings, 
  Coffee, 
  LogOut,
  Store,
  X,
  Lock
} from 'lucide-react';
import { NavigationTab } from '../types';
import { useAuth } from '../context/AuthContext';

interface SidebarProps {
  currentTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  activeOrdersCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  mobileOpen,
  onCloseMobile,
  activeOrdersCount,
}) => {
  const { restaurant, userProfile, logout } = useAuth();

  const navItems: { id: NavigationTab; label: string; icon: React.ElementType; badge?: number; isLocked?: boolean }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'tables', label: 'Tables', icon: UtensilsCrossed },
    { id: 'active-orders', label: 'Active Orders', icon: ClipboardList, badge: activeOrdersCount > 0 ? activeOrdersCount : undefined },
    { id: 'payments', label: 'Payments', icon: Receipt, isLocked: true },
    { id: 'menu-management', label: 'Menu Management', icon: BookOpen },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const handleNavClick = (tab: NavigationTab) => {
    onSelectTab(tab);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile backdrop */}
      {mobileOpen && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-black/40 backdrop-blur-xs md:hidden"
        />
      )}

      {/* Sidebar container */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-[#2D1B0E] text-[#F3EBE1] flex flex-col transition-transform duration-300 ease-in-out md:translate-x-0 md:static ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        } border-r border-[#3E2514] shadow-2xl md:shadow-none`}
      >
        {/* Brand Header */}
        <div className="h-20 px-6 flex items-center justify-between border-b border-[#3E2514]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#613A1E] flex items-center justify-center text-[#FDFBF7] shadow-inner">
              <Coffee className="w-5 h-5 text-[#F2DFCD]" strokeWidth={2.4} />
            </div>
            <div>
              <span className="text-xl font-bold font-serif text-[#FDFBF7] tracking-tight block leading-tight">
                CafeDMS
              </span>
              <span className="text-[10px] text-[#CBB29C] font-mono tracking-wider uppercase">
                Restaurant System
              </span>
            </div>
          </div>
          <button
            onClick={onCloseMobile}
            className="md:hidden text-[#CBB29C] hover:text-white p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Restaurant Info Card */}
        <div className="px-4 py-4">
          <div className="bg-[#3A2312] rounded-xl p-3 border border-[#4C2E18]">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#F2DFCD] truncate">
              <Store className="w-3.5 h-3.5 text-[#D19B6F] shrink-0" />
              <span className="truncate">{restaurant?.name || 'CafeDMS'}</span>
            </div>
            <div className="text-[11px] text-[#A68872] truncate mt-0.5">
              ID: {restaurant?.id || '—'}
            </div>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 px-3 py-2 space-y-1.5 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-[#522E14] text-[#FFFFFF] shadow-sm font-semibold'
                    : 'text-[#CBB29C] hover:bg-[#38200F] hover:text-[#F2DFCD]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={`w-5 h-5 ${
                      isActive ? 'text-[#E5B589]' : 'text-[#A68872]'
                    }`}
                  />
                  <span>{item.label}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  {item.isLocked && (
                    <Lock className="w-3.5 h-3.5 text-[#B59C86]/70" />
                  )}
                  {item.badge !== undefined && (
                    <span className="px-2 py-0.5 text-xs font-bold rounded-full bg-[#8C5835] text-[#FFF]">
                      {item.badge}
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </nav>

        {/* Footer / User Profile & Logout */}
        <div className="p-4 border-t border-[#3E2514] bg-[#24150B]/60">
          <div className="flex items-center justify-between">
            <div className="min-w-0 flex-1 mr-2">
              <p className="text-xs font-semibold text-[#FDFBF7] truncate">
                {userProfile?.managerName || userProfile?.email || 'Restaurant Manager'}
              </p>
              <p className="text-[10px] text-[#A68872] uppercase tracking-wider truncate">
                {userProfile?.role === 'manager' ? 'Restaurant Manager' : (userProfile?.role || 'Manager')}
              </p>
            </div>
            <button
              onClick={() => logout()}
              title="Log Out"
              className="p-2 text-[#CBB29C] hover:text-[#F87171] hover:bg-[#38200F] rounded-lg transition-colors"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
