import React, { useState } from 'react';
import { X, CheckCircle, CreditCard, Banknote, Smartphone, AlertCircle } from 'lucide-react';
import { useRestaurantData } from '../context/RestaurantDataContext';
import { Order, PaymentMethod } from '../types';

interface PaymentModalProps {
  order: Order | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  order,
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { recordPayment } = useRestaurantData();

  const [method, setMethod] = useState<PaymentMethod>('Telebirr');
  const [amountStr, setAmountStr] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  React.useEffect(() => {
    if (order) {
      // Default amount input to the exact remaining balance for fast 1-click settlement
      setAmountStr(order.remainingBalance.toFixed(2));
      setErrorMsg(null);
    }
  }, [order, isOpen]);

  if (!isOpen || !order) return null;

  const amountNumber = parseFloat(amountStr) || 0;
  const newRemainingPreview = Math.max(0, order.remainingBalance - amountNumber);
  const willBeFullyPaid = amountNumber >= order.remainingBalance;

  const handleSavePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (isNaN(amountNumber) || amountNumber <= 0) {
      setErrorMsg('Please enter a valid payment amount greater than zero.');
      return;
    }

    if (amountNumber > order.remainingBalance) {
      setErrorMsg(
        `Payment amount (ETB ${amountNumber.toFixed(2)}) cannot exceed the remaining balance of ETB ${order.remainingBalance.toFixed(2)}.`
      );
      return;
    }

    setSubmitting(true);
    try {
      await recordPayment({
        orderId: order.id,
        method,
        amount: amountNumber,
      });
      if (onSuccess) onSuccess();
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to record payment. Please retry.');
    } finally {
      setSubmitting(false);
    }
  };

  const paymentOptions: { id: PaymentMethod; label: string; icon: React.ElementType; desc: string }[] = [
    { id: 'Cash', label: 'Cash', icon: Banknote, desc: 'Physical cash received' },
    { id: 'Telebirr', label: 'Telebirr', icon: Smartphone, desc: 'Mobile money transfer' },
    { id: 'CBE', label: 'CBE', icon: CreditCard, desc: 'Commercial Bank of Ethiopia transfer' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-[#FFFDF9] border border-[#EADBCE] rounded-2xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#EADBCE] flex items-center justify-between bg-[#FDF8F2]">
          <div>
            <h2 className="text-lg font-bold font-serif text-[#3A2010]">
              Save Payment
            </h2>
            <p className="text-xs text-[#8C6D53]">
              {order.orderNumber} • {order.tableName || 'Takeaway'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-[#9E826C] hover:text-[#3A2010] p-1.5 rounded-lg hover:bg-[#F2E8DC]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSavePayment} className="p-6 space-y-4">
          
          {/* Order Financial Overview */}
          <div className="bg-[#FAF4EC] border border-[#E8D4BF] rounded-xl p-3.5 space-y-2 text-xs">
            <div className="flex justify-between text-[#6B4226]">
              <span>Order Total:</span>
              <span className="font-mono font-bold text-[#3A2010]">
                ETB {order.totalAmount.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between text-[#7D6352]">
              <span>Amount Already Paid:</span>
              <span className="font-mono font-semibold text-[#28662F]">
                ETB {order.amountPaid.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between text-[#3A2010] pt-2 border-t border-[#E8D4BF] font-bold text-sm">
              <span>Remaining Balance:</span>
              <span className="font-mono text-[#A63A24]">
                ETB {order.remainingBalance.toFixed(2)}
              </span>
            </div>
          </div>

          {/* Payment Method Selector */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#6B4226] mb-2">
              Select Payment Method
            </label>
            <div className="grid grid-cols-3 gap-2">
              {paymentOptions.map((opt) => {
                const Icon = opt.icon;
                const isSelected = method === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setMethod(opt.id)}
                    className={`p-3 rounded-xl border flex flex-col items-center justify-center text-center transition-all ${
                      isSelected
                        ? 'bg-[#4A2E18] text-white border-[#4A2E18] shadow-sm font-bold'
                        : 'bg-white text-[#6B4226] border-[#D9C8B5] hover:bg-[#FAF4EC]'
                    }`}
                  >
                    <Icon className={`w-5 h-5 mb-1 ${isSelected ? 'text-[#F2DFCD]' : 'text-[#8C5835]'}`} />
                    <span className="text-xs font-semibold">{opt.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Amount Received Input */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold uppercase tracking-wider text-[#6B4226]">
                Amount Received (ETB)
              </label>
              <button
                type="button"
                onClick={() => setAmountStr(order.remainingBalance.toFixed(2))}
                className="text-[11px] font-semibold text-[#8C5835] hover:underline"
              >
                Pay Full (ETB {order.remainingBalance.toFixed(2)})
              </button>
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-xs font-bold text-[#8C6D53]">
                ETB
              </div>
              <input
                type="number"
                step="any"
                min="0.01"
                max={order.remainingBalance}
                value={amountStr}
                onChange={(e) => setAmountStr(e.target.value)}
                placeholder="0.00"
                className="w-full pl-12 pr-4 py-2.5 bg-white border border-[#D9C8B5] rounded-xl text-sm font-mono font-bold text-[#3A2010] focus:outline-none focus:ring-2 focus:ring-[#8C5835]"
                required
              />
            </div>
          </div>

          {/* Balance Preview */}
          <div className="bg-[#FDFBF7] border border-[#EADBCE] rounded-xl p-3 text-xs flex items-center justify-between">
            <span className="text-[#7D6352]">Balance after this payment:</span>
            <span className="font-mono font-bold text-[#3A2010]">
              ETB {newRemainingPreview.toFixed(2)}
            </span>
          </div>

          {/* Fully Paid notice or partial note */}
          <div className="text-xs">
            {willBeFullyPaid ? (
              <span className="text-[#28662F] font-semibold flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 shrink-0" />
                This will settle the order in full and release {order.tableName || 'the table'}.
              </span>
            ) : (
              <span className="text-[#8C5835] font-medium">
                This is a partial payment. The order will remain active with the updated remaining balance.
              </span>
            )}
          </div>

          {errorMsg && (
            <div className="p-3 bg-[#FDF0ED] border border-[#F5C6BA] rounded-xl text-xs text-[#A63A24] flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Action Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={submitting || amountNumber <= 0}
              className="w-full py-3 px-4 bg-[#4A2E18] hover:bg-[#38200F] text-[#FFFDF9] font-bold text-sm rounded-xl shadow-md transition-all disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
            >
              {submitting ? (
                <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <CheckCircle className="w-4 h-4" />
                  <span>Save Payment</span>
                </>
              )}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
