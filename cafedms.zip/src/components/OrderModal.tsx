import React, { useState, useMemo } from 'react';
import { 
  X, 
  UtensilsCrossed, 
  ShoppingBag, 
  Plus, 
  Minus, 
  Trash2, 
  Search, 
  CheckCircle,
  AlertTriangle 
} from 'lucide-react';
import { useRestaurantData } from '../context/RestaurantDataContext';
import { ImagePreview } from './ImagePreview';
import { MenuItem, OrderItem, Order } from '../types';

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialType?: 'dine-in' | 'takeaway';
  initialTableId?: string;
  onSwitchToAddItems?: (order: Order) => void;
}

export const OrderModal: React.FC<OrderModalProps> = ({
  isOpen,
  onClose,
  initialType = 'dine-in',
  initialTableId,
  onSwitchToAddItems,
}) => {
  const { menuItems, tables, orders, createOrder } = useRestaurantData();

  // Mode: 'dine-in' or 'takeaway'
  const [orderType, setOrderType] = useState<'dine-in' | 'takeaway'>(initialType);
  const [selectedTableId, setSelectedTableId] = useState<string>(initialTableId || '');

  // Filter / Search for menu items
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  // Selected items in cart: map itemId -> quantity
  const [cart, setCart] = useState<{ [itemId: string]: number }>({});
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Sync initial props
  React.useEffect(() => {
    if (initialType) setOrderType(initialType);
    if (initialTableId) setSelectedTableId(initialTableId);
    setCart({});
    setErrorMsg(null);
  }, [initialType, initialTableId, isOpen]);

  // Categories list
  const categories = useMemo(() => {
    const set = new Set<string>();
    menuItems.forEach((item) => {
      if (item.category) set.add(item.category);
    });
    return ['All', ...Array.from(set)];
  }, [menuItems]);

  // Only AVAILABLE menu items can be ordered
  const availableMenuItems = useMemo(() => {
    return menuItems.filter((item) => item.isAvailable);
  }, [menuItems]);

  const filteredMenuItems = useMemo(() => {
    return availableMenuItems.filter((item) => {
      const matchSearch =
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category.toLowerCase().includes(searchQuery.toLowerCase());
      const matchCat = selectedCategory === 'All' || item.category === selectedCategory;
      return matchSearch && matchCat;
    });
  }, [availableMenuItems, searchQuery, selectedCategory]);

  // Check if selected table already has an active order
  const existingTableOrder = useMemo(() => {
    if (orderType !== 'dine-in' || !selectedTableId) return null;
    return orders.find(
      (o) => o.status === 'active' && o.tableId === selectedTableId
    );
  }, [orderType, selectedTableId, orders]);

  // Selected Table object
  const selectedTable = useMemo(() => {
    return tables.find((t) => t.id === selectedTableId);
  }, [tables, selectedTableId]);

  // Cart calculation
  const cartItems: OrderItem[] = useMemo(() => {
    return Object.entries(cart)
      .filter(([_, qty]) => qty > 0)
      .map(([itemId, qty]) => {
        const item = menuItems.find((m) => m.id === itemId);
        const price = item ? item.price : 0;
        const name = item ? item.name : 'Unknown Item';
        return {
          itemId,
          name,
          price,
          quantity: qty,
          subtotal: price * qty,
        };
      });
  }, [cart, menuItems]);

  const totalAmount = useMemo(() => {
    return cartItems.reduce((sum, item) => sum + item.subtotal, 0);
  }, [cartItems]);

  const updateQuantity = (itemId: string, delta: number) => {
    setCart((prev) => {
      const current = prev[itemId] || 0;
      const next = current + delta;
      if (next <= 0) {
        const copy = { ...prev };
        delete copy[itemId];
        return copy;
      }
      return { ...prev, [itemId]: next };
    });
  };

  const removeItem = (itemId: string) => {
    setCart((prev) => {
      const copy = { ...prev };
      delete copy[itemId];
      return copy;
    });
  };

  const handleSaveOrder = async () => {
    setErrorMsg(null);

    if (orderType === 'dine-in' && !selectedTableId) {
      setErrorMsg('Please select a dining table for Dine In order.');
      return;
    }

    if (existingTableOrder) {
      setErrorMsg(
        `${selectedTable?.name || 'This table'} already has an active order (${existingTableOrder.orderNumber}). Please add items to that order instead of creating a duplicate.`
      );
      return;
    }

    if (cartItems.length === 0) {
      setErrorMsg('Please select at least one menu item.');
      return;
    }

    setSubmitting(true);
    try {
      await createOrder({
        orderType,
        tableId: orderType === 'dine-in' ? selectedTableId : undefined,
        tableName: orderType === 'dine-in' ? selectedTable?.name : 'Takeaway',
        items: cartItems,
        totalAmount,
      });
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to save order.');
    } finally {
      setSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-[#FFFDF9] border border-[#EADBCE] rounded-2xl w-full max-w-5xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#EADBCE] flex items-center justify-between bg-[#FDF8F2]">
          <div className="flex items-center gap-3">
            <h2 className="text-xl font-bold font-serif text-[#3A2010]">
              Create New Order
            </h2>
            {/* Dine In / Takeaway Pills */}
            <div className="flex items-center bg-[#F2E8DC] p-1 rounded-xl border border-[#D9C8B5]">
              <button
                type="button"
                onClick={() => setOrderType('dine-in')}
                className={`flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                  orderType === 'dine-in'
                    ? 'bg-[#4A2E18] text-[#FFFDF9] shadow-xs'
                    : 'text-[#6B4226] hover:text-[#3A2010]'
                }`}
              >
                <UtensilsCrossed className="w-3.5 h-3.5" />
                <span>Dine In</span>
              </button>
              <button
                type="button"
                onClick={() => setOrderType('takeaway')}
                className={`flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                  orderType === 'takeaway'
                    ? 'bg-[#4A2E18] text-[#FFFDF9] shadow-xs'
                    : 'text-[#6B4226] hover:text-[#3A2010]'
                }`}
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>Takeaway</span>
              </button>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#9E826C] hover:text-[#3A2010] p-1.5 rounded-lg hover:bg-[#F2E8DC]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body: Left = Menu Selection, Right = Order Summary */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
          
          {/* Left Column (8 cols): Menu items */}
          <div className="lg:col-span-7 xl:col-span-8 flex flex-col border-b lg:border-b-0 lg:border-r border-[#EADBCE] p-4 sm:p-5 overflow-hidden">
            
            {/* Table Selection for Dine In */}
            {orderType === 'dine-in' && (
              <div className="mb-4 p-3 bg-[#FAF2E8] border border-[#E8D4BF] rounded-xl">
                <label className="block text-xs font-bold uppercase tracking-wider text-[#6B4226] mb-1.5">
                  Select Dining Table:
                </label>
                <div className="flex flex-wrap gap-2 max-h-24 overflow-y-auto">
                  {tables.map((t) => {
                    const isOccupied = t.status === 'occupied';
                    const isSelected = selectedTableId === t.id;
                    return (
                      <button
                        key={t.id}
                        type="button"
                        onClick={() => setSelectedTableId(t.id)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                          isSelected
                            ? 'bg-[#4A2E18] text-white border-[#4A2E18] shadow-xs'
                            : isOccupied
                            ? 'bg-[#FDF0ED] text-[#A63A24] border-[#F5C6BA]'
                            : 'bg-white text-[#3A2010] border-[#D9C8B5] hover:border-[#8C5835]'
                        }`}
                      >
                        {t.name} {isOccupied && '(Occupied)'}
                      </button>
                    );
                  })}
                </div>

                {/* Warning if occupied table selected */}
                {existingTableOrder && (
                  <div className="mt-2.5 p-2.5 bg-[#FFF2E0] border border-[#F2C288] rounded-lg text-xs text-[#964B00] flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 shrink-0 text-[#E37400]" />
                      <span>
                        <strong>{selectedTable?.name}</strong> already has active order{' '}
                        <strong>{existingTableOrder.orderNumber}</strong>.
                      </span>
                    </div>
                    {onSwitchToAddItems && (
                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          onSwitchToAddItems(existingTableOrder);
                        }}
                        className="underline font-bold text-[#6B4226] hover:text-[#3A2010]"
                      >
                        Add to order &rarr;
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Menu Filters: Search & Category tabs */}
            <div className="flex flex-col sm:flex-row gap-2 mb-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-[#A89078]" />
                <input
                  type="text"
                  placeholder="Search menu..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-[#D9C8B5] rounded-xl text-[#3A2010] focus:outline-none focus:ring-1 focus:ring-[#8C5835]"
                />
              </div>

              {/* Categories horizontally scrollable */}
              <div className="flex gap-1 overflow-x-auto pb-1 max-w-full">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-2.5 py-1 text-xs rounded-lg font-medium shrink-0 transition-colors ${
                      selectedCategory === cat
                        ? 'bg-[#4A2E18] text-[#FFFDF9]'
                        : 'bg-[#F2E8DC] text-[#6B4226] hover:bg-[#EADBCE]'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Menu Items List */}
            <div className="flex-1 overflow-y-auto pr-1 space-y-2">
              {filteredMenuItems.length === 0 ? (
                <div className="text-center py-12 text-xs text-[#9E826C]">
                  {availableMenuItems.length === 0
                    ? 'No available items in menu. Please add or enable items in Menu Management.'
                    : 'No matching items found.'}
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {filteredMenuItems.map((item) => {
                    const inCartQty = cart[item.id] || 0;
                    return (
                      <div
                        key={item.id}
                        className={`p-2.5 bg-white border rounded-xl flex items-center justify-between gap-3 transition-all ${
                          inCartQty > 0
                            ? 'border-[#8C5835] bg-[#FAF5EF]'
                            : 'border-[#EADBCE] hover:border-[#CBB29C]'
                        }`}
                      >
                        {/* Image preview & Info */}
                        <div className="flex items-center gap-2.5 min-w-0">
                          {item.imageUrl ? (
                            <ImagePreview
                              url={item.imageUrl}
                              altText={item.name}
                              className="w-12 h-12 shrink-0 rounded-lg"
                            />
                          ) : null}
                          <div className="min-w-0">
                            <h4 className="text-xs font-bold text-[#3A2010] truncate">
                              {item.name}
                            </h4>
                            <span className="text-[10px] text-[#8C6D53] block truncate">
                              {item.category}
                            </span>
                            <span className="text-xs font-mono font-bold text-[#6B4226]">
                              ETB {item.price.toFixed(2)}
                            </span>
                          </div>
                        </div>

                        {/* Quantity Counter */}
                        <div className="flex items-center gap-1.5 shrink-0">
                          {inCartQty > 0 ? (
                            <>
                              <button
                                type="button"
                                onClick={() => updateQuantity(item.id, -1)}
                                className="w-6 h-6 rounded-md bg-[#F2E8DC] text-[#4A2E18] flex items-center justify-center hover:bg-[#EADBCE]"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                              <span className="w-6 text-center text-xs font-bold text-[#3A2010]">
                                {inCartQty}
                              </span>
                              <button
                                type="button"
                                onClick={() => updateQuantity(item.id, 1)}
                                className="w-6 h-6 rounded-md bg-[#4A2E18] text-white flex items-center justify-center hover:bg-[#38200F]"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            </>
                          ) : (
                            <button
                              type="button"
                              onClick={() => updateQuantity(item.id, 1)}
                              className="px-2.5 py-1 text-xs font-bold bg-[#F2E8DC] hover:bg-[#4A2E18] text-[#4A2E18] hover:text-white rounded-lg transition-colors"
                            >
                              + Add
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

          </div>

          {/* Right Column (4-5 cols): Order Review & Cart Summary */}
          <div className="lg:col-span-5 xl:col-span-4 bg-[#FDFBF7] p-4 sm:p-5 flex flex-col justify-between overflow-hidden">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-[#EADBCE] mb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-[#6B4226]">
                  Order Items ({cartItems.reduce((acc, c) => acc + c.quantity, 0)})
                </span>
                <span className="text-xs text-[#8C6D53] font-medium">
                  {orderType === 'dine-in'
                    ? selectedTable
                      ? selectedTable.name
                      : 'No table selected'
                    : 'Takeaway'}
                </span>
              </div>

              {/* Items List */}
              <div className="overflow-y-auto max-h-[36vh] space-y-2 pr-1">
                {cartItems.length === 0 ? (
                  <p className="text-center py-10 text-xs text-[#A89078]">
                    No items selected yet. Tap "+ Add" on any menu item to build order.
                  </p>
                ) : (
                  cartItems.map((item) => (
                    <div
                      key={item.itemId}
                      className="flex items-center justify-between bg-white p-2.5 rounded-xl border border-[#EADBCE] text-xs"
                    >
                      <div className="min-w-0 flex-1 mr-2">
                        <div className="font-bold text-[#3A2010] truncate">
                          {item.name}
                        </div>
                        <div className="text-[11px] text-[#8C6D53]">
                          {item.quantity} × ETB {item.price.toFixed(2)}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-[#4A2E18]">
                          ETB {item.subtotal.toFixed(2)}
                        </span>
                        <button
                          type="button"
                          onClick={() => removeItem(item.itemId)}
                          className="text-[#B59C86] hover:text-[#C45E47] p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Bottom Total & Save */}
            <div className="pt-4 border-t border-[#EADBCE] mt-4">
              {errorMsg && (
                <div className="mb-3 p-2.5 bg-[#FDF0ED] border border-[#F5C6BA] rounded-xl text-xs text-[#A63A24] font-medium">
                  {errorMsg}
                </div>
              )}

              <div className="space-y-1.5 mb-4 text-xs">
                <div className="flex justify-between text-[#7D6352]">
                  <span>Subtotal:</span>
                  <span className="font-mono">ETB {totalAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold text-sm text-[#3A2010] pt-1 border-t border-[#EADBCE]/60">
                  <span>Total Amount:</span>
                  <span className="font-mono text-base text-[#4A2E18]">
                    ETB {totalAmount.toFixed(2)}
                  </span>
                </div>
              </div>

              <button
                type="button"
                disabled={submitting || cartItems.length === 0 || (orderType === 'dine-in' && !selectedTableId) || !!existingTableOrder}
                onClick={handleSaveOrder}
                className="w-full py-3 px-4 bg-[#4A2E18] hover:bg-[#38200F] text-[#FFFDF9] font-bold text-sm rounded-xl shadow-md transition-all disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
              >
                {submitting ? (
                  <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <CheckCircle className="w-4 h-4" />
                    <span>Save Order (Active Orders)</span>
                  </>
                )}
              </button>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
