import React, { useState, useEffect } from 'react';
import { ImageOff } from 'lucide-react';

interface ImagePreviewProps {
  url?: string;
  altText: string;
  className?: string;
}

export const ImagePreview: React.FC<ImagePreviewProps> = ({ url, altText, className = '' }) => {
  const [hasError, setHasError] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setHasError(false);
    setIsLoading(true);
  }, [url]);

  if (!url || url.trim() === '') {
    return (
      <div className={`flex flex-col items-center justify-center bg-[#F7F2EA] border border-[#E8DEC8] text-[#8C6D53] rounded-lg p-3 text-center text-xs ${className}`}>
        <ImageOff className="w-5 h-5 mb-1 text-[#A89078]" />
        <span>No image provided</span>
      </div>
    );
  }

  if (hasError) {
    return (
      <div className={`flex flex-col items-center justify-center bg-[#FDF0ED] border border-[#F5C6BA] text-[#A63A24] rounded-lg p-3 text-center text-xs ${className}`}>
        <ImageOff className="w-5 h-5 mb-1 text-[#C45E47]" />
        <span>Image preview unavailable</span>
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden rounded-lg bg-[#F7F2EA] border border-[#E8DEC8] ${className}`}>
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#F7F2EA] text-xs text-[#8C6D53] animate-pulse">
          Loading preview...
        </div>
      )}
      <img
        src={url.trim()}
        alt={altText}
        className={`w-full h-full object-cover transition-opacity duration-300 ${isLoading ? 'opacity-0' : 'opacity-100'}`}
        onLoad={() => setIsLoading(false)}
        onError={() => {
          setIsLoading(false);
          setHasError(true);
        }}
      />
    </div>
  );
};
