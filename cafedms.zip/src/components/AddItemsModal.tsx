import React, { useState, useMemo } from 'react';
import { X, Plus, Minus, Search, CheckCircle, Trash2 } from 'lucide-react';
import { useRestaurantData } from '../context/RestaurantDataContext';
import { ImagePreview } from './ImagePreview';
import { Order, OrderItem } from '../types';

interface AddItemsModalProps {
  order: Order | null;
  isOpen: boolean;
  onClose: () => void;
}

export const AddItemsModal: React.FC<AddItemsModalProps> = ({
  order,
  isOpen,
  onClose,
}) => {
  const { menuItems, addItemsToExistingOrder } = useRestaurantData();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [cart, setCart] = useState<{ [itemId: string]: number }>({});
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  React.useEffect(() => {
    setCart({});
    setErrorMsg(null);
  }, [order, isOpen]);

  const categories = useMemo(() => {
    const set = new Set<string>();
    menuItems.forEach((item) => {
      if (item.category) set.add(item.category);
    });
    return ['All', ...Array.from(set)];
  }, [menuItems]);

  const availableMenuItems = useMemo(() => {
    return menuItems.filter((item) => item.isAvailable);
  }, [menuItems]);

  const filteredMenuItems = useMemo(() => {
    return availableMenuItems.filter((item) => {
      const matchSearch =
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category.toLowerCase().includes(searchQuery.toLowerCase());
      const matchCat = selectedCategory === 'All' || item.category === selectedCategory;
      return matchSearch && matchCat;
    });
  }, [availableMenuItems, searchQuery, selectedCategory]);

  const newItemsToAdd: OrderItem[] = useMemo(() => {
    return Object.entries(cart)
      .filter(([_, qty]) => qty > 0)
      .map(([itemId, qty]) => {
        const item = menuItems.find((m) => m.id === itemId);
        const price = item ? item.price : 0;
        const name = item ? item.name : 'Item';
        return {
          itemId,
          name,
          price,
          quantity: qty,
          subtotal: price * qty,
        };
      });
  }, [cart, menuItems]);

  const additionalTotal = useMemo(() => {
    return newItemsToAdd.reduce((sum, it) => sum + it.subtotal, 0);
  }, [newItemsToAdd]);

  const updateQuantity = (itemId: string, delta: number) => {
    setCart((prev) => {
      const current = prev[itemId] || 0;
      const next = current + delta;
      if (next <= 0) {
        const copy = { ...prev };
        delete copy[itemId];
        return copy;
      }
      return { ...prev, [itemId]: next };
    });
  };

  const removeItem = (itemId: string) => {
    setCart((prev) => {
      const copy = { ...prev };
      delete copy[itemId];
      return copy;
    });
  };

  const handleSaveAdditionalItems = async () => {
    if (!order) return;
    if (newItemsToAdd.length === 0) {
      setErrorMsg('Please select at least one item to add.');
      return;
    }

    setSubmitting(true);
    try {
      await addItemsToExistingOrder(order.id, newItemsToAdd);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to add items to order.');
    } finally {
      setSubmitting(false);
    }
  };

  if (!isOpen || !order) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-[#FFFDF9] border border-[#EADBCE] rounded-2xl w-full max-w-4xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#EADBCE] flex items-center justify-between bg-[#FDF8F2]">
          <div>
            <h2 className="text-lg font-bold font-serif text-[#3A2010]">
              Add Items to Order {order.orderNumber}
            </h2>
            <p className="text-xs text-[#8C6D53]">
              {order.tableName || (order.orderType === 'dine-in' ? 'Table' : 'Takeaway')} • Current Total: ETB {order.totalAmount.toFixed(2)}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-[#9E826C] hover:text-[#3A2010] p-1.5 rounded-lg hover:bg-[#F2E8DC]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 overflow-hidden">
          
          {/* Menu selection (7 cols) */}
          <div className="md:col-span-7 p-4 border-b md:border-b-0 md:border-r border-[#EADBCE] flex flex-col overflow-hidden">
            {/* Search & Categories */}
            <div className="flex flex-col gap-2 mb-3">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-[#A89078]" />
                <input
                  type="text"
                  placeholder="Search menu..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-[#D9C8B5] rounded-xl text-[#3A2010]"
                />
              </div>
              <div className="flex gap-1 overflow-x-auto pb-1">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-2.5 py-1 text-xs rounded-lg font-medium shrink-0 ${
                      selectedCategory === cat
                        ? 'bg-[#4A2E18] text-white'
                        : 'bg-[#F2E8DC] text-[#6B4226] hover:bg-[#EADBCE]'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Menu List */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {filteredMenuItems.map((item) => {
                const inCartQty = cart[item.id] || 0;
                return (
                  <div
                    key={item.id}
                    className="p-2 bg-white border border-[#EADBCE] rounded-xl flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      {item.imageUrl && (
                        <ImagePreview
                          url={item.imageUrl}
                          altText={item.name}
                          className="w-10 h-10 shrink-0"
                        />
                      )}
                      <div className="min-w-0">
                        <div className="font-bold text-[#3A2010] truncate">{item.name}</div>
                        <div className="text-[10px] text-[#8C6D53]">{item.category}</div>
                        <div className="font-mono font-bold text-[#6B4226]">
                          ETB {item.price.toFixed(2)}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      {inCartQty > 0 ? (
                        <>
                          <button
                            type="button"
                            onClick={() => updateQuantity(item.id, -1)}
                            className="w-5 h-5 rounded bg-[#F2E8DC] text-[#4A2E18] flex items-center justify-center font-bold"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-5 text-center font-bold text-[#3A2010]">
                            {inCartQty}
                          </span>
                          <button
                            type="button"
                            onClick={() => updateQuantity(item.id, 1)}
                            className="w-5 h-5 rounded bg-[#4A2E18] text-white flex items-center justify-center font-bold"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </>
                      ) : (
                        <button
                          type="button"
                          onClick={() => updateQuantity(item.id, 1)}
                          className="px-2 py-1 bg-[#F2E8DC] hover:bg-[#4A2E18] text-[#4A2E18] hover:text-white rounded-lg font-bold"
                        >
                          + Add
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* New items review (5 cols) */}
          <div className="md:col-span-5 bg-[#FDFBF7] p-4 flex flex-col justify-between overflow-hidden">
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-[#6B4226] pb-2 border-b border-[#EADBCE] mb-2">
                Items to Add ({newItemsToAdd.reduce((a, b) => a + b.quantity, 0)})
              </div>

              <div className="overflow-y-auto max-h-[30vh] space-y-1.5 pr-1">
                {newItemsToAdd.length === 0 ? (
                  <p className="text-center py-8 text-xs text-[#A89078]">
                    Select items from the menu to append.
                  </p>
                ) : (
                  newItemsToAdd.map((it) => (
                    <div
                      key={it.itemId}
                      className="p-2 bg-white rounded-lg border border-[#EADBCE] text-xs flex items-center justify-between"
                    >
                      <div>
                        <div className="font-bold text-[#3A2010]">{it.name}</div>
                        <div className="text-[10px] text-[#8C6D53]">
                          {it.quantity} × ETB {it.price.toFixed(2)}
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono font-bold text-[#4A2E18]">
                          ETB {it.subtotal.toFixed(2)}
                        </span>
                        <button
                          type="button"
                          onClick={() => removeItem(it.itemId)}
                          className="text-[#B59C86] hover:text-[#C45E47] p-0.5"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Calculations & Submit */}
            <div className="pt-3 border-t border-[#EADBCE] mt-3">
              {errorMsg && (
                <div className="mb-2 p-2 bg-[#FDF0ED] border border-[#F5C6BA] rounded text-xs text-[#A63A24]">
                  {errorMsg}
                </div>
              )}

              <div className="space-y-1 text-xs mb-3">
                <div className="flex justify-between text-[#7D6352]">
                  <span>Existing Order Total:</span>
                  <span className="font-mono">ETB {order.totalAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-[#7D6352]">
                  <span>Additional Items:</span>
                  <span className="font-mono">+ ETB {additionalTotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold text-sm text-[#3A2010] pt-1 border-t border-[#EADBCE]">
                  <span>New Total:</span>
                  <span className="font-mono text-[#4A2E18]">
                    ETB {(order.totalAmount + additionalTotal).toFixed(2)}
                  </span>
                </div>
              </div>

              <button
                type="button"
                disabled={submitting || newItemsToAdd.length === 0}
                onClick={handleSaveAdditionalItems}
                className="w-full py-2.5 px-4 bg-[#4A2E18] hover:bg-[#38200F] text-white font-bold text-xs rounded-xl transition-colors disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer shadow-sm"
              >
                {submitting ? (
                  <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <CheckCircle className="w-4 h-4" />
                    <span>Update Order</span>
                  </>
                )}
              </button>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
