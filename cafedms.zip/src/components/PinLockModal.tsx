import React, { useState, useEffect, useRef } from 'react';
import { Lock, X, Check, AlertCircle, Delete, KeyRound } from 'lucide-react';

interface PinLockModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  title?: string;
  description?: string;
  requiredPin?: string;
}

export const PinLockModal: React.FC<PinLockModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  title = 'Manager Payment Authorization',
  description = 'Please enter the 6-digit manager authorization PIN to continue.',
  requiredPin = '506790',
}) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setPin('');
      setError(false);
      setErrorMessage('');
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleDigit = (digit: string) => {
    if (pin.length < 6) {
      const nextPin = pin + digit;
      setPin(nextPin);
      setError(false);
      setErrorMessage('');

      if (nextPin.length === 6) {
        verifyPin(nextPin);
      }
    }
  };

  const handleBackspace = () => {
    setPin((prev) => prev.slice(0, -1));
    setError(false);
    setErrorMessage('');
  };

  const verifyPin = (candidatePin: string) => {
    if (candidatePin === requiredPin) {
      setError(false);
      setErrorMessage('');
      onSuccess();
    } else {
      setError(true);
      setErrorMessage('Incorrect PIN. Please enter the valid authorization PIN.');
      setPin('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key >= '0' && e.key <= '9') {
      handleDigit(e.key);
    } else if (e.key === 'Backspace') {
      handleBackspace();
    } else if (e.key === 'Escape') {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#FFFDF9] border border-[#EADBCE] rounded-3xl w-full max-w-sm shadow-2xl overflow-hidden flex flex-col p-6 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-[#4A2E18] text-[#FDFBF7] flex items-center justify-center shadow-md shadow-[#4A2E18]/15">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold font-serif text-[#3A2010]">
                {title}
              </h3>
              <p className="text-[11px] text-[#8C6D53]">
                Security PIN Required
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#9E826C] hover:text-[#3A2010] p-1.5 rounded-xl hover:bg-[#F2E8DC] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-[#7D6352] mb-5 text-center leading-relaxed">
          {description}
        </p>

        {/* Hidden input for physical keyboard focus */}
        <input
          ref={inputRef}
          type="password"
          maxLength={6}
          value={pin}
          onChange={() => {}}
          onKeyDown={handleKeyDown}
          className="opacity-0 absolute pointer-events-none -top-10"
          autoFocus
        />

        {/* PIN Dots Display */}
        <div 
          onClick={() => inputRef.current?.focus()}
          className="flex justify-center items-center gap-3 mb-6 cursor-pointer py-2"
        >
          {[0, 1, 2, 3, 4, 5].map((index) => {
            const hasDigit = index < pin.length;
            return (
              <div
                key={index}
                className={`w-10 h-12 rounded-xl flex items-center justify-center text-xl font-bold font-mono transition-all ${
                  error
                    ? 'border-2 border-[#C45E47] bg-[#FDF0ED] text-[#A63A24] animate-shake'
                    : hasDigit
                    ? 'border-2 border-[#4A2E18] bg-[#F5ECE1] text-[#3A2010] shadow-xs'
                    : 'border border-[#D9C8B5] bg-[#FDFBF7] text-[#B5A08E]'
                }`}
              >
                {hasDigit ? '•' : ''}
              </div>
            );
          })}
        </div>

        {/* Error message */}
        {errorMessage && (
          <div className="mb-4 p-2.5 bg-[#FDF0ED] border border-[#F5C6BA] rounded-xl text-xs text-[#A63A24] flex items-center justify-center gap-2 text-center font-medium">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Number Keypad */}
        <div className="grid grid-cols-3 gap-2.5 mb-2">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              type="button"
              onClick={() => handleDigit(digit)}
              className="py-3 bg-[#FAF5EF] hover:bg-[#F2E8DC] active:bg-[#4A2E18] active:text-white border border-[#E8DCCF] rounded-2xl text-lg font-bold text-[#3A2010] transition-colors shadow-2xs cursor-pointer select-none"
            >
              {digit}
            </button>
          ))}
          <button
            type="button"
            onClick={() => setPin('')}
            className="py-3 bg-[#FAF5EF] hover:bg-[#F2E8DC] text-[#7D6352] text-xs font-bold rounded-2xl transition-colors cursor-pointer"
          >
            Clear
          </button>
          <button
            type="button"
            onClick={() => handleDigit('0')}
            className="py-3 bg-[#FAF5EF] hover:bg-[#F2E8DC] active:bg-[#4A2E18] active:text-white border border-[#E8DCCF] rounded-2xl text-lg font-bold text-[#3A2010] transition-colors shadow-2xs cursor-pointer select-none"
          >
            0
          </button>
          <button
            type="button"
            onClick={handleBackspace}
            className="py-3 bg-[#FAF5EF] hover:bg-[#F2E8DC] text-[#7D6352] hover:text-[#A63A24] flex items-center justify-center rounded-2xl transition-colors cursor-pointer"
            title="Backspace"
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>

        {/* Footer Note */}
        <div className="mt-4 pt-3 border-t border-[#EADBCE] text-center text-[11px] text-[#8C6D53] flex items-center justify-center gap-1.5">
          <KeyRound className="w-3 h-3 text-[#B59C86]" />
          <span>Payment authorization lock is enabled</span>
        </div>

      </div>
    </div>
  );
};
