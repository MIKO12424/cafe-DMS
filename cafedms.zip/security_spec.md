# CafeDMS Security Specification

## 1. Data Invariants
1. **Tenant Isolation:** A user authenticated with Firebase can only access resources under `/restaurants/{restaurantId}` if `/restaurants/{restaurantId}` has `ownerId == request.auth.uid` or the user's profile maps them to that restaurant.
2. **User Profile Integrity:** A user document at `/users/{userId}` can only be created/updated by the user whose UID matches `{userId}`, and the user cannot set unauthorized admin flags.
3. **Restaurant Ownership:** A restaurant document at `/restaurants/{restaurantId}` can only be created by an authenticated user setting `ownerId: request.auth.uid`. Updates can only be made by the owner.
4. **Order Integrity:** An order must have a valid positive or zero `totalAmount`, valid items array, and valid status (`active`, `completed`, `cancelled`).
5. **Payment Immutability & Validity:** Payments are append-only (create allowed, updates prohibited). `amount` must be greater than 0, and method must be one of `Cash`, `Telebirr`, or `CBE`.
6. **Menu Item Integrity:** Name and category cannot be empty, price must be a non-negative number.

## 2. The Dirty Dozen Payloads (Designed to Break Security)
1. **Cross-Tenant Restaurant Access:** User A trying to read or write to `/restaurants/restaurant_B/orders/order_1`.
2. **Orphaned User Creation:** An unauthenticated user writing to `/users/fake_id`.
3. **Spoofed User ID:** User A writing to `/users/user_B` with `request.auth.uid == user_A`.
4. **Negative Payment Amount:** User attempting to record a payment with `amount: -50`.
5. **Invalid Payment Method:** User writing a payment with `method: "Bitcoin"` or `"CreditCardDirect"`.
6. **Mutating Immutable Payment:** User attempting an `update` or `delete` on an existing payment document in `/restaurants/{restaurantId}/payments/{paymentId}`.
7. **Negative Menu Price:** User creating a menu item with `price: -100`.
8. **Empty Menu Name:** User creating a menu item with `name: ""`.
9. **Corrupt Order Status:** User updating an order with `status: "hacked_status"`.
10. **Arbitrary Restaurant Ownership Stealing:** User B attempting to update `ownerId` of `/restaurants/restaurant_A` to their own UID.
11. **Huge ID Resource Poisoning:** Attempting to create a document with an ID exceeding 128 characters or containing SQL injection characters.
12. **Negative Order Total:** Submitting an order with `totalAmount: -500`.
